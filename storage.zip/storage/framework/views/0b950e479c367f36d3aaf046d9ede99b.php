<?php
$overridesCss = app(\App\Services\ThemeService::class)->getAllOverridesCss();
?>
<!doctype html>
<html lang="pt-BR" data-theme="verde">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'Loja Teste'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($overridesCss): ?>
        <style id="database-theme-tokens"><?php echo $overridesCss; ?></style>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</head>
<body style="margin:0;background:#f5f5f5;">
    <?php echo e($slot); ?>

</body>
</html>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/layouts/storefront.blade.php ENDPATH**/ ?>