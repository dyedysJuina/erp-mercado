<div>
    <div x-data="{ show: <?php if ((object) ('toastShow') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'->value()); ?>')<?php echo e('toastShow'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'); ?>')<?php endif; ?>, msg: <?php if ((object) ('toastMsg') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'->value()); ?>')<?php echo e('toastMsg'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'); ?>')<?php endif; ?> }"
         x-init="$watch('show', val => { if(val) setTimeout(() => show = false, 4000) })"
         x-show="show" class="toast-fixed" x-cloak>
        <span class="toast-icon"><i class="fas fa-check"></i></span><span x-text="msg"></span>
    </div>
    <div class="main-content-pad">
        <div class="header-row">
            <div>
                <div class="admin-badge"><i class="fas fa-crown"></i> ADMIN</div>
                <h1 class="page-title">DRE — Resultado do Exercício</h1>
                <div class="breadcrumb">
                    <span>Início</span><i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <span>Relatórios</span><i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <span class="breadcrumb-active">DRE</span>
                </div>
            </div>
            <div class="status-online"><span class="status-dot"></span> Conectado</div>
        </div>

        <div class="sub-card" style="margin-bottom:16px;display:flex;gap:10px;align-items:end;flex-wrap:wrap;">
            <div class="field" style="width:150px;margin:0;"><label>Loja</label><select wire:model.live="lojaFiltro" style="height:38px;font-size:12px;"><option value="">Todas</option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->lojas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><option value="<?php echo e($l['id']); ?>"><?php echo e($l['nome']); ?></option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></select></div>
            <div class="field" style="width:100px;margin:0;"><label>Mês</label><select wire:model.live="mes" style="height:38px;font-size:12px;"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><option value="<?php echo e(str_pad($m,2,'0',STR_PAD_LEFT)); ?>"><?php echo e(str_pad($m,2,'0',STR_PAD_LEFT)); ?></option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></select></div>
            <div class="field" style="width:100px;margin:0;"><label>Ano</label><select wire:model.live="ano" style="height:38px;font-size:12px;"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($a = now()->year - 2; $a <= now()->year; $a++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><option value="<?php echo e($a); ?>"><?php echo e($a); ?></option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></select></div>
        </div>

        <?php $d = $this->dre; ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start;">
            
            <div class="card" style="padding:20px;">
                <h3 style="margin:0 0 16px;font-size:16px;font-weight:800;color:var(--text);">Demonstrativo — <?php echo e($d['mes']); ?>/<?php echo e($d['ano']); ?></h3>

                <div style="padding:12px 0;border-bottom:2px solid var(--text);">
                    <div style="display:flex;justify-content:space-between;font-size:14px;font-weight:700;color:var(--text);text-transform:uppercase;">
                        <span>Receita Bruta (Vendas)</span>
                        <span style="color:var(--success);">R$ <?php echo e(number_format($d['receita_bruta'], 2, ',', '.')); ?></span>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($d['receitas_financeiras'] > 0): ?>
                        <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--muted);margin-top:4px;">
                            <span>Receitas Financeiras</span>
                            <span style="color:var(--success);">R$ <?php echo e(number_format($d['receitas_financeiras'], 2, ',', '.')); ?></span>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div style="padding:12px 0;border-bottom:1px solid var(--border);">
                    <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--text);">
                        <span>(−) Custo das Mercadorias (CMV)</span>
                        <span style="color:var(--danger);">− R$ <?php echo e(number_format($d['cmv'], 2, ',', '.')); ?></span>
                    </div>
                </div>

                <div style="padding:12px 0;border-bottom:2px solid var(--text);">
                    <div style="display:flex;justify-content:space-between;font-size:15px;font-weight:700;color:var(--text);">
                        <span>= Lucro Bruto</span>
                        <span style="<?php echo e($d['lucro_bruto'] >= 0 ? 'color:var(--success);' : 'color:var(--danger);'); ?>">R$ <?php echo e(number_format($d['lucro_bruto'], 2, ',', '.')); ?></span>
                    </div>
                    <div style="font-size:12px;color:var(--muted);text-align:right;">Margem Bruta: <?php echo e($d['margem_bruta']); ?>%</div>
                </div>

                <div style="padding:12px 0;border-bottom:1px solid var(--border);">
                    <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--text);">
                        <span>(−) Despesas Operacionais</span>
                        <span style="color:var(--danger);">− R$ <?php echo e(number_format($d['despesas'], 2, ',', '.')); ?></span>
                    </div>
                </div>

                <div style="padding:16px 0 0;">
                    <div style="display:flex;justify-content:space-between;font-size:18px;font-weight:900;">
                        <span>Resultado Líquido</span>
                        <span style="<?php echo e($d['resultado_liquido'] >= 0 ? 'color:var(--success);' : 'color:var(--danger);'); ?>">
                            R$ <?php echo e(number_format($d['resultado_liquido'], 2, ',', '.')); ?>

                        </span>
                    </div>
                    <div style="font-size:13px;color:var(--muted);text-align:right;margin-top:4px;">Margem Líquida: <?php echo e($d['margem_liquida']); ?>%</div>
                </div>
            </div>

            
            <div style="display:flex;flex-direction:column;gap:12px;">
                <div class="metric-card" style="padding:16px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div><span class="metric-label" style="font-size:10px;">Margem Bruta</span><span class="metric-value" style="font-size:24px;<?php echo e($d['margem_bruta'] >= 20 ? 'color:var(--success);' : ($d['margem_bruta'] >= 10 ? 'color:var(--warning);' : 'color:var(--danger);')); ?>"><?php echo e($d['margem_bruta']); ?>%</span></div>
                        <div class="metric-icon green" style="width:40px;height:40px;font-size:16px;"><i class="fas fa-percentage"></i></div>
                    </div>
                    <div style="margin-top:8px;height:6px;border-radius:3px;background:color-mix(in srgb,var(--text)8%,var(--surface));overflow:hidden;">
                        <div style="height:100%;border-radius:3px;width:<?php echo e(min(100, $d['margem_bruta'] * 3)); ?>%;background:<?php echo e($d['margem_bruta'] >= 20 ? 'var(--success)' : ($d['margem_bruta'] >= 10 ? 'var(--warning)' : 'var(--danger)')); ?>;"></div>
                    </div>
                </div>

                <div class="metric-card" style="padding:16px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div><span class="metric-label" style="font-size:10px;">Margem Líquida</span><span class="metric-value" style="font-size:24px;<?php echo e($d['margem_liquida'] >= 0 ? 'color:var(--success);' : 'color:var(--danger);'); ?>"><?php echo e($d['margem_liquida']); ?>%</span></div>
                        <div class="metric-icon blue" style="width:40px;height:40px;font-size:16px;"><i class="fas fa-chart-line"></i></div>
                    </div>
                </div>

                <div class="metric-card" style="padding:16px;">
                    <div><span class="metric-label" style="font-size:10px;">Contas a Pagar (mês)</span><span class="metric-value" style="font-size:20px;color:var(--danger);">R$ <?php echo e(number_format($d['a_pagar'], 2, ',', '.')); ?></span></div>
                </div>

                <div class="metric-card" style="padding:16px;">
                    <div><span class="metric-label" style="font-size:10px;">Custo Total (CMV + Despesas)</span><span class="metric-value" style="font-size:20px;">R$ <?php echo e(number_format($d['cmv'] + $d['despesas'], 2, ',', '.')); ?></span></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/dre-manager.blade.php ENDPATH**/ ?>