<div>
    <div x-data="{ show: <?php if ((object) ('toastShow') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'->value()); ?>')<?php echo e('toastShow'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'); ?>')<?php endif; ?>, msg: <?php if ((object) ('toastMsg') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'->value()); ?>')<?php echo e('toastMsg'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'); ?>')<?php endif; ?> }"
         x-init="$watch('show', val => { if(val) setTimeout(() => show = false, 4000) })"
         x-show="show" class="toast-fixed" x-cloak>
        <span class="toast-icon"><i class="fas fa-check"></i></span><span x-text="msg"></span>
    </div>
    <div class="main-content-pad">
        <div class="header-row">
            <div>
                <div class="admin-badge"><i class="fas fa-crown"></i> ADMIN</div>
                <h1 class="page-title">Sugestão de Compras</h1>
                <div class="breadcrumb">
                    <span>Início</span><i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <span>Operacional</span><i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <span class="breadcrumb-active">Sugestão de Compras</span>
                </div>
            </div>
            <div class="status-online"><span class="status-dot"></span> Conectado</div>
        </div>

        <?php $resumo = $this->resumo; ?>
        <div class="metrics-grid" style="grid-template-columns:repeat(4,1fr);">
            <div class="metric-card" style="padding:14px;border-left:4px solid var(--danger);">
                <div><span class="metric-label">🔴 Críticos</span><span class="metric-value" style="font-size:20px;color:var(--danger);"><?php echo e($resumo['criticos']); ?></span><span class="metric-sub">Precisam comprar URGENTE</span></div>
            </div>
            <div class="metric-card" style="padding:14px;border-left:4px solid var(--warning);">
                <div><span class="metric-label">🟡 Atenção</span><span class="metric-value" style="font-size:20px;color:var(--warning);"><?php echo e($resumo['media']); ?></span><span class="metric-sub">Vão acabar em breve</span></div>
            </div>
            <div class="metric-card" style="padding:14px;">
                <div><span class="metric-label">Sugestão Total</span><span class="metric-value" style="font-size:20px;"><?php echo e(number_format($resumo['sugestao_total'], 0, ',', '.')); ?> un</span><span class="metric-sub">Somar de todos os itens</span></div>
            </div>
            <div class="metric-card" style="padding:14px;">
                <div><span class="metric-label">Custo Total</span><span class="metric-value" style="font-size:20px;">R$ <?php echo e(number_format($resumo['custo_total'], 2, ',', '.')); ?></span><span class="metric-sub">Investimento necessário</span></div>
            </div>
        </div>

        <div class="sub-card" style="margin-bottom:16px;display:flex;gap:10px;align-items:end;flex-wrap:wrap;">
            <div class="field" style="width:150px;margin:0;"><label>Loja *</label><select wire:model.live="lojaFiltro" style="height:38px;font-size:12px;"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->lojas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><option value="<?php echo e($l['id']); ?>"><?php echo e($l['nome']); ?></option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></select></div>
            <div class="field" style="width:150px;margin:0;"><label>Departamento</label><select wire:model.live="categoriaFiltro" style="height:38px;font-size:12px;"><option value="">Todos</option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><option value="<?php echo e($c['nome']); ?>"><?php echo e($c['nome']); ?></option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></select></div>
            <div class="field" style="width:100px;margin:0;"><label>Base (dias)</label><select wire:model.live="diasBase" style="height:38px;font-size:12px;"><option value="15">15</option><option value="30">30</option><option value="60">60</option><option value="90">90</option></select></div>
            <div class="field" style="width:110px;margin:0;"><label>Lead Time</label><select wire:model.live="diasReposicao" style="height:38px;font-size:12px;"><option value="7">7 dias</option><option value="15">15 dias</option><option value="21">21 dias</option><option value="30">30 dias</option></select></div>
            <div class="field" style="width:120px;margin:0;"><label>Urgência</label><select wire:model.live="filtroUrgencia" style="height:38px;font-size:12px;"><option value="">Todas</option><option value="critica">🔴 Crítica</option><option value="media">🟡 Atenção</option></select></div>
        </div>

        <div class="data-table-wrap">
            <div style="overflow-x:auto;">
                <?php $sugestoes = $this->sugestoes(); ?>
                <table class="data-table" style="font-size:12px;">
                    <thead><tr>
                        <th class="data-table-th text-left">Produto</th>
                        <th class="data-table-th text-left">Depto</th>
                        <th class="data-table-th text-right">Venda Média</th>
                        <th class="data-table-th text-right">Estoque</th>
                        <th class="data-table-th text-right">Mínimo</th>
                        <th class="data-table-th text-center">Dias</th>
                        <th class="data-table-th text-right">Sugerido</th>
                        <th class="data-table-th text-right">Custo</th>
                        <th class="data-table-th text-center">Status</th>
                    </tr></thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $sugestoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr class="data-table-tr" style="<?php echo e($s['urgencia'] === 'critica' ? 'background:color-mix(in srgb,var(--danger)4%,transparent);' : ($s['urgencia'] === 'media' ? 'background:color-mix(in srgb,var(--warning)3%,transparent);' : '')); ?>">
                                <td class="data-table-td font-semibold" style="text-transform:uppercase;font-size:11px;"><?php echo e($s['nome']); ?></td>
                                <td class="data-table-td text-muted" style="font-size:10px;"><?php echo e($s['categoria']); ?></td>
                                <td class="data-table-td text-right font-semibold"><?php echo e(number_format($s['venda_media'], 3, ',', '.')); ?>/dia</td>
                                <td class="data-table-td text-right font-bold <?php echo e($s['estoque_atual'] <= $s['estoque_min'] ? 'text-danger' : ''); ?>"><?php echo e(number_format($s['estoque_atual'], 3, ',', '.')); ?></td>
                                <td class="data-table-td text-right text-muted"><?php echo e(number_format($s['estoque_min'], 3, ',', '.')); ?></td>
                                <td class="data-table-td text-center font-bold" style="<?php echo e($s['dias_ate_zero'] <= 7 ? 'color:var(--danger);' : ($s['dias_ate_zero'] <= 15 ? 'color:var(--warning);' : 'color:var(--muted);')); ?>"><?php echo e($s['dias_ate_zero']); ?> dias</td>
                                <td class="data-table-td text-right font-bold" style="color:var(--primary-600);"><?php echo e(number_format($s['sugestao'], 0, ',', '.')); ?> un</td>
                                <td class="data-table-td text-right text-muted">R$ <?php echo e(number_format($s['custo'], 2, ',', '.')); ?></td>
                                <td class="data-table-td text-center">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($s['urgencia'] === 'critica'): ?>
                                        <span class="badge-sm badge-inativo" style="font-size:9px;">🔴 Crítico</span>
                                    <?php elseif($s['urgencia'] === 'media'): ?>
                                        <span class="badge-sm badge-warning" style="font-size:9px;">🟡 Atenção</span>
                                    <?php else: ?>
                                        <span class="badge-sm badge-ativo" style="font-size:9px;">✅ OK</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr><td colspan="9" class="data-table-empty">Nenhum produto encontrado. Selecione uma loja com vendas.</td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/sugestao-compra-manager.blade.php ENDPATH**/ ?>