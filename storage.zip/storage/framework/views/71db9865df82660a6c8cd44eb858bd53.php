<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>DANFE NFC-e #<?php echo e($doc->numero); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Courier New', monospace; font-size: 11px; color: #000; background: #fff; padding: 8px; }
        .cupom { max-width: 302px; margin: 0 auto; }
        .center { text-align: center; }
        .linha { border-top: 1px dashed #000; margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; font-size: 10px; }
        th { padding: 3px 0; text-align: left; font-weight: 700; border-bottom: 1px solid #000; }
        td { padding: 2px 0; vertical-align: top; }
        .direita { text-align: right; }
        .centro { text-align: center; }
        .mono { font-family: 'Courier New', monospace; }
        .qrcode { text-align: center; margin: 8px 0; }
        .qrcode-placeholder { width: 110px; height: 110px; border: 2px solid #000; display: inline-flex; align-items: center; justify-content: center; font-size: 9px; color: #666; }
        .chave { font-size: 9px; word-break: break-all; }
        .totals { margin-top: 4px; }
        .totals tr td { padding: 2px 0; font-weight: 700; }
        .totals .linha { border-top: 1px solid #000; margin: 2px 0; }
        @media print { @page { margin: 0; size: 80mm auto; } body { padding: 4px; } }
    </style>
</head>
<body>
    <div class="cupom">
        <div class="center">
            <strong style="font-size:13px;"><?php echo e($loja->nome); ?></strong><br>
            <?php echo e($loja->logradouro ?? ''); ?>, <?php echo e($loja->numero ?? 'S/N'); ?><br>
            <?php echo e($loja->bairro ?? ''); ?> - <?php echo e($loja->cidade?->nome ?? $loja->cidade ?? ''); ?> / <?php echo e($loja->cidade?->estado?->uf ?? $loja->uf ?? 'MT'); ?><br>
            CNPJ: <?php echo e($loja->cnpj); ?><br>
            IE: <?php echo e($loja->inscricao_estadual ?? 'ISENTO'); ?>

        </div>
        <div class="linha"></div>
        <div class="center">
            <strong>DANFE NFC-e</strong><br>
            Documento Auxiliar da Nota Fiscal Eletrônica<br>
            NFC-e - Modelo 65 - Série <?php echo e($doc->serie); ?>

        </div>
        <div class="linha"></div>
        <table>
            <tr><td style="width:60px;"><strong>Número</strong></td><td><?php echo e($doc->numero); ?></td></tr>
            <tr><td><strong>Data</strong></td><td><?php echo e($doc->emitida_at->format('d/m/Y H:i:s')); ?></td></tr>
            <tr><td><strong>Consumidor</strong></td><td><?php echo e($doc->cliente?->nome ?? 'NÃO IDENTIFICADO'); ?></td></tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($doc->cliente?->cpf): ?>
                <tr><td><strong>CPF</strong></td><td><?php echo e($doc->cliente->cpf); ?></td></tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </table>
        <div class="linha"></div>
        <table>
            <thead>
                <tr>
                    <th style="width:20px;">Cód.</th>
                    <th>Descrição</th>
                    <th style="width:30px;" class="direita">Qtd</th>
                    <th style="width:50px;" class="direita">Valor</th>
                    <th style="width:50px;" class="direita">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $nItem = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $doc->itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php
                        $nItem++;
                        $gtin = $i->variacao?->codigosBarras?->firstWhere('principal', true)?->codigo ?? '';
                        $nome = $i->variacao?->nome_completo ?? 'Produto #' . $i->produto_variacao_id;
                    ?>
                    <tr>
                        <td style="font-size:9px;"><?php echo e($nItem); ?></td>
                        <td>
                            <span style="font-weight:600;"><?php echo e($nome); ?></span>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($gtin): ?>
                                <span style="display:block;font-size:8px;color:#666;">GTIN: <?php echo e($gtin); ?></span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>
                        <td class="direita"><?php echo e(number_format($i->quantidade, 3, ',', '.')); ?></td>
                        <td class="direita"><?php echo e(number_format($i->valor_unitario, 2, ',', '.')); ?></td>
                        <td class="direita"><?php echo e(number_format($i->valor_total, 2, ',', '.')); ?></td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
        <div class="linha"></div>
        <table class="totals">
            <tr><td style="font-weight:700;font-size:11px;">Valor Total</td><td class="direita" style="font-weight:900;font-size:14px;">R$ <?php echo e(number_format($doc->valor_total, 2, ',', '.')); ?></td></tr>
        </table>
        <div class="linha"></div>
        <div class="center chave">
            <strong style="font-size:10px;">Chave de Acesso</strong><br>
            <?php echo e($doc->chave_acesso); ?><br>
            <small style="font-size:8px;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($doc->status === 'rascunho'): ?>
                    NFC-e em RASCUNHO - sem valor fiscal
                <?php else: ?>
                    Consulte pela Chave de Acesso em www.sefaz.mt.gov.br
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </small>
        </div>
        <div class="linha"></div>
        <div class="qrcode">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($doc->status === 'rascunho'): ?>
                <div class="qrcode-placeholder">QR Code<br>(disponível após<br>autorização)</div>
            <?php else: ?>
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=110x110&data=<?php echo e($doc->chave_acesso); ?>" alt="QR Code NFC-e" style="width:110px;height:110px;">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="center" style="font-size:8px;">
            <strong>ERP Mercado</strong> — <?php echo e($doc->created_at->format('d/m/Y H:i')); ?>

        </div>
        <div style="text-align:center;margin-top:8px;font-size:9px;font-weight:700;">
            OBRIGADO E VOLTE SEMPRE!
        </div>
    </div>
    <script>
        <?php if($doc->status !== 'rascunho'): ?>
            window.print();
        <?php endif; ?>
    </script>
</body>
</html>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/fiscal/danfe-nfce.blade.php ENDPATH**/ ?>