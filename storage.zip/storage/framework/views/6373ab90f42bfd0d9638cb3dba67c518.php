<div>
    <script src="/js/html5-qrcode.min.js"></script>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->passo === 'inicio'): ?>
        <?php echo $__env->make('livewire.pdv.inicio', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->passo === 'venda'): ?>
        <?php echo $__env->make('livewire.pdv.venda', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->passo === 'pagamento'): ?>
        <?php echo $__env->make('livewire.pdv.pagamento', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->passo === 'finalizada'): ?>
        <?php echo $__env->make('livewire.pdv.finalizada', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<script>
function pdvApp() {
    return {
        showScanner: false, scanError: null, qr: null,
        showClientModal: false, showDiscountModal: false,
        currentTime: '', currentDate: '', searchTimer: null,
        isFullscreen: false,
        init() {
            this.updateClock();
            setInterval(() => this.updateClock(), 1000);
            this.$nextTick(() => { if (this.$refs.searchInput) this.$refs.searchInput.focus(); });
            window.addEventListener('beforeunload', (e) => {
                if (this.$wire.get('passo') === 'venda' && this.$wire.get('carrinho',[]).length > 0) {
                    e.preventDefault();
                    e.returnValue = '';
                }
            });
            document.addEventListener('fullscreenchange', () => {
                this.isFullscreen = !!document.fullscreenElement;
            });
        },
        toggleFullscreen() {
            if (document.fullscreenElement) {
                document.exitFullscreen().catch(() => {});
            } else {
                document.documentElement.requestFullscreen().catch(() => {});
            }
        },
        updateClock() {
            const n = new Date();
            this.currentTime = n.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
            this.currentDate = n.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
        },
        scheduleSearch(val) {
            clearTimeout(this.searchTimer);
            this.searchTimer = setTimeout(() => this.$wire.set('buscaProduto', val), 300);
        },
        searchEnter() {
            const val = this.$refs.searchInput?.value;
            if (val && val.length > 0) this.$wire.call('adicionarProdutoPorCodigo', val);
        },
        numpad(val) {
            if (!this.$refs.searchInput) return;
            if (val === 'bs') this.$refs.searchInput.value = this.$refs.searchInput.value.slice(0, -1);
            else if (val === 'limpar') this.$refs.searchInput.value = '';
            else this.$refs.searchInput.value += val;
            this.$refs.searchInput.dispatchEvent(new Event('input'));
            this.$refs.searchInput.focus();
        },
        openScanner() {
            this.showScanner = true; this.scanError = null;
            this.$nextTick(() => {
                const el = document.getElementById('scanner-elem');
                if (!el || typeof Html5Qrcode === 'undefined') { this.scanError = 'Biblioteca não carregada'; return; }
                if (!window.isSecureContext) { this.scanError = 'Câmera exige HTTPS'; return; }
                this.qr = new Html5Qrcode('scanner-elem');
                this.qr.start({ facingMode: 'environment' }, { fps: 15, qrbox: { width: 250, height: 150 } },
                    (texto) => { this.closeScanner(); this.$refs.searchInput.value = texto; this.$wire.call('adicionarProdutoPorCodigo', texto); }
                ).catch(e => { this.scanError = e.message; });
            });
        },
        closeScanner() { if (this.qr) { this.qr.stop().catch(() => {}); this.qr = null; } this.showScanner = false; this.$nextTick(() => this.$refs.searchInput?.focus()); },
        cancelItem() { this.$wire.get('carrinho', []).then(cart => { if (cart.length > 0) this.$wire.call('removerItem', cart.length - 1); }); },
        showClient() { this.showClientModal = true; this.showDiscountModal = false; },
        showDiscount() { this.showDiscountModal = true; this.showClientModal = false; },
        handleKey(e) {
            if (e.key === 'Escape') { this.showScanner = false; this.showClientModal = false; this.showDiscountModal = false; }
            if (e.key === 'F2') { e.preventDefault(); this.$wire.call('novaVenda'); }
        }
    }
}
</script>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/venda-manager.blade.php ENDPATH**/ ?>