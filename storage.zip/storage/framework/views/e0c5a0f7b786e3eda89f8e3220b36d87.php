<div wire:poll.60s="atualizar"
     x-data="{
         count: <?php if ((object) ('count') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('count'->value()); ?>')<?php echo e('count'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('count'); ?>')<?php endif; ?>,
         sinal: <?php if ((object) ('sinal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('sinal'->value()); ?>')<?php echo e('sinal'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('sinal'); ?>')<?php endif; ?>,
         init() {
             this.$watch('sinal', () => { this.tocarSom(); });
         },
         tocarSom() {
             try {
                 const a = new Audio('/sounds/notification.mp3');
                 a.volume = 0.5;
                 a.play().catch(() => this.tocarSomFallback());
             } catch(e) { this.tocarSomFallback(); }
         },
         tocarSomFallback() {
             try {
                 const ctx = new (window.AudioContext || window.webkitAudioContext)();
                 const o = ctx.createOscillator();
                 const g = ctx.createGain();
                 const o2 = ctx.createOscillator();
                 const g2 = ctx.createGain();
                 o.connect(g);
                 g.connect(ctx.destination);
                 o2.connect(g2);
                 g2.connect(ctx.destination);
                 o.frequency.value = 830;
                 o2.frequency.value = 1100;
                 o.type = 'sine';
                 o2.type = 'sine';
                 g.gain.value = 0.25;
                 g2.gain.value = 0.15;
                 o.start();
                 o2.start();
                 g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
                 g2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
                 setTimeout(() => { o.stop(); o2.stop(); }, 300);
             } catch(e) {}
         }
     }"
     style="display:inline-block;">
    <a href="<?php echo e(route('notificacoes')); ?>" wire:navigate style="position:relative;color:var(--muted);font-size:18px;text-decoration:none;">
        <i class="fas fa-bell bell-icon"></i>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($count > 0): ?>
            <span style="position:absolute;top:-6px;right:-8px;display:flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 4px;border-radius:999px;background:var(--danger);color:#fff;font-size:10px;font-weight:800;line-height:1;"><?php echo e($count > 99 ? '99+' : $count); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </a>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/notification-bell.blade.php ENDPATH**/ ?>