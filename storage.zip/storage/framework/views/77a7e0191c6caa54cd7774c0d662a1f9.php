<div>
    
    <div x-data="{ show: <?php if ((object) ('toastShow') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'->value()); ?>')<?php echo e('toastShow'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'); ?>')<?php endif; ?>, msg: <?php if ((object) ('toastMsg') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'->value()); ?>')<?php echo e('toastMsg'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'); ?>')<?php endif; ?> }"
         x-init="$watch('show', val => { if(val) setTimeout(() => show = false, 4000) })"
         x-show="show" x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0 translate-y-2 scale-95"
         x-transition:enter-end="opacity-100 translate-y-0 scale-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100 translate-y-0 scale-100"
         x-transition:leave-end="opacity-0 translate-y-2 scale-95"
         class="toast-fixed" x-cloak>
        <span class="toast-icon"><i class="fas fa-check"></i></span>
        <span x-text="msg"></span>
    </div>

    <div class="main-content-pad">

        
        <div class="header-row">
            <div>
                <div class="admin-badge"><i class="fas fa-crown"></i> ADMIN</div>
                <h1 class="page-title">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($viewState === 'list'): ?>
                        Clientes
                    <?php elseif($viewState === 'create'): ?>
                        Novo Cliente
                    <?php else: ?>
                        <?php echo e($this->nome ?: 'Cliente'); ?>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </h1>
                <div class="breadcrumb">
                    <span>Início</span>
                    <i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <span>Cadastros</span>
                    <i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($viewState !== 'list'): ?>
                        <span style="cursor:pointer;color:var(--primary-600);font-weight:600;" wire:click="voltarLista">Clientes</span>
                        <i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <span class="breadcrumb-active"><?php echo e($viewState === 'list' ? 'Clientes' : ($viewState === 'create' ? 'Novo' : $this->nome)); ?></span>
                </div>
            </div>
            <div class="status-online"><span class="status-dot"></span> Conectado</div>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($viewState === 'list'): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button wire:click="novo" class="btn-primary btn-lg"><i class="fas fa-plus"></i> Novo Cliente</button>
            </div>
        </div>

        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-icon purple"><i class="fas fa-users"></i></div>
                <div><span class="metric-label">Total</span><span class="metric-value"><?php echo e($this->totalGeral); ?></span><span class="metric-sub">Clientes cadastrados</span></div>
            </div>
            <div class="metric-card">
                <div class="metric-icon green"><i class="fas fa-circle-check"></i></div>
                <div><span class="metric-label">Ativos</span><span class="metric-value"><?php echo e($this->totalAtivos); ?></span><span class="metric-sub green">Em operação</span></div>
            </div>
            <div class="metric-card">
                <div class="metric-icon amber"><i class="fas fa-circle-minus"></i></div>
                <div><span class="metric-label">Inativos</span><span class="metric-value"><?php echo e($this->totalInativos); ?></span><span class="metric-sub amber">Desativados</span></div>
            </div>
            <div class="metric-card">
                <div class="metric-icon blue"><i class="fas fa-id-card"></i></div>
                <div><span class="metric-label">Com CPF</span><span class="metric-value"><?php echo e($this->totalComCpf); ?></span><span class="metric-sub">Possuem CPF</span></div>
            </div>
        </div>

        <div class="search-card">
            <div class="search-input-wrap">
                <i class="fas fa-search search-input-icon"></i>
                <input wire:model.live.debounce.300ms="busca" placeholder="Buscar por nome, CPF, email ou whatsapp..." class="search-input-field">
            </div>
        </div>

        <div class="data-table-wrap">
            <div class="data-table-header">
                <span class="data-table-title"><i class="fas fa-table-list"></i> Clientes <span class="data-table-count">(<?php echo e($this->totalGeral); ?>)</span></span>
            </div>
            <div style="overflow-x:auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th class="data-table-th text-left">Nome</th>
                            <th class="data-table-th text-left">Email / CPF</th>
                            <th class="data-table-th text-center">WhatsApp</th>
                            <th class="data-table-th text-center">Endereços</th>
                            <th class="data-table-th text-center">Status</th>
                            <th class="data-table-th text-center" style="width:160px;">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $lista = $this->lista(); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr class="data-table-tr">
                                <td class="data-table-td font-bold cursor-pointer" wire:click="selecionar(<?php echo e($c['id']); ?>)"><?php echo e($c['nome']); ?></td>
                                <td class="data-table-td"><?php echo e($c['email'] ?? '—'); ?><br><span class="font-mono text-muted" style="font-size:11px;"><?php echo e($c['cpf'] ?? ''); ?></span></td>
                                <td class="data-table-td text-center font-mono"><?php echo e($c['whatsapp'] ?? '—'); ?></td>
                                <td class="data-table-td text-center"><?php echo e($c['enderecos_count']); ?></td>
                                <td class="data-table-td text-center">
                                    <span class="badge-sm <?php echo e($c['ativo'] ? 'badge-ativo' : 'badge-inativo'); ?>"><?php echo e($c['ativo'] ? 'Ativo' : 'Inativo'); ?></span>
                                </td>
                                <td class="data-table-td text-center">
                                    <div class="table-actions">
                                        <button wire:click="selecionar(<?php echo e($c['id']); ?>)" class="table-action-btn" style="color:var(--primary-600);" title="Abrir"><i class="fas fa-eye"></i></button>
                                        <button wire:click="desativar(<?php echo e($c['id']); ?>)" class="table-action-btn" style="color:<?php echo e($c['ativo'] ? 'var(--warning)' : 'var(--success)'); ?>;" title="<?php echo e($c['ativo'] ? 'Desativar' : 'Ativar'); ?>"><i class="fas <?php echo e($c['ativo'] ? 'fa-toggle-on' : 'fa-toggle-off'); ?>"></i></button>
                                        <button wire:click="excluir(<?php echo e($c['id']); ?>)" wire:confirm="Excluir cliente?" class="table-action-btn" style="color:var(--danger);" title="Excluir"><i class="fas fa-trash-alt"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr><td colspan="6" class="data-table-empty">Nenhum cliente encontrado.</td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lista->hasPages()): ?>
                <div style="padding:12px 16px;border-top:1px solid var(--border);">
                    <?php echo e($lista->links('livewire.pagination-custom')); ?>

                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($viewState === 'create' || $viewState === 'detail'): ?>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
            <button wire:click="voltarLista" class="subheader-btn"><i class="fas fa-arrow-left"></i> Voltar</button>
            <div style="width:1px;height:24px;background:var(--border);"></div>
            <div>
                <span style="font-size:16px;font-weight:900;color:var(--text);"><?php echo e($viewState === 'create' ? 'Novo Cliente' : $this->nome); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($viewState === 'detail'): ?>
                <span class="badge-ativo-sm" style="margin-left:8px;"><?php echo e($this->ativo ? 'Ativo' : 'Inativo'); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="grid-2col-custom">
            
            <div>
                <div class="form-card" x-data="{ activeTab: '<?php echo e($viewState === 'create' ? 'principal' : 'compras'); ?>' }">
                    <div class="form-card-header">
                        <span class="form-card-title"><i class="fas fa-user form-card-icon"></i> <?php echo e($viewState === 'create' ? 'Novo Cliente' : 'Dados do Cliente'); ?></span>
                        <span class="form-card-subtitle"><?php echo e($viewState === 'create' ? 'Preencha os dados do novo cliente.' : 'Gerencie todas as informações do cliente.'); ?></span>
                    </div>

                    
                    <div class="tab-nav">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($viewState === 'create'): ?>
                        <button @click="activeTab = 'principal'" :class="activeTab === 'principal' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-info-circle"></i> Principal</button>
                        <button @click="activeTab = 'enderecos'" :class="activeTab === 'enderecos' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-map-marker-alt"></i> Endereços</button>
                        <button @click="activeTab = 'config'" :class="activeTab === 'config' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-cog"></i> Config</button>
                        <?php else: ?>
                        <button @click="activeTab = 'compras'" :class="activeTab === 'compras' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-shopping-bag"></i> Compras</button>
                        <button @click="activeTab = 'financeiro'" :class="activeTab === 'financeiro' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-chart-line"></i> Financeiro</button>
                        <button @click="activeTab = 'principal'" :class="activeTab === 'principal' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-info-circle"></i> Dados</button>
                        <button @click="activeTab = 'enderecos'" :class="activeTab === 'enderecos' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-map-marker-alt"></i> Endereços</button>
                        <button @click="activeTab = 'grupos'" :class="activeTab === 'grupos' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-layer-group"></i> Grupos</button>
                        <button @click="activeTab = 'fidelidade'" :class="activeTab === 'fidelidade' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-gem"></i> Fidelidade</button>
                        <button @click="activeTab = 'config'" :class="activeTab === 'config' ? 'tab-btn tab-btn-active' : 'tab-btn'"><i class="fas fa-cog"></i> Config</button>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <form wire:submit="salvar" class="form-body">
                        
                        <div x-show="activeTab === 'principal'">
                            <div class="section-border">Dados do Cliente</div>
                            <div class="grid-2" style="margin-bottom:12px;">
                                <div class="field"><label>Nome *</label><input wire:model="nome" placeholder="Nome completo"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                                <div class="field"><label>Email</label><input wire:model="email" type="email" placeholder="cliente@email.com"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                            </div>
                            <div class="grid-3" style="margin-bottom:12px;">
                                <div class="field"><label>CPF</label><input wire:model.live="cpf" placeholder="000.000.000-00" x-data x-mask="999.999.999-99"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                                <div class="field"><label>WhatsApp</label><input wire:model="whatsapp" placeholder="(66) 99999-9999" x-data x-mask="(99) 99999-9999"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                                <div class="field"><label>Data Nascimento</label><input wire:model="data_nascimento" type="date"></div>
                            </div>
                        </div>

                        
                        <div x-show="activeTab === 'enderecos'">
                            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                                <span class="section-border" style="margin-bottom:0;">Endereços</span>
                                <button type="button" wire:click="adicionarEndereco" class="btn-sm btn-secondary">+ Adicionar</button>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $end): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <div class="sub-card" style="margin-bottom:10px;position:relative;" x-data="{
                                    cep<?php echo e($idx); ?>: '<?php echo e(preg_replace('/\D/', '', $end['cep'] ?? '')); ?>',
                                    cepErro<?php echo e($idx); ?>: '', buscando<?php echo e($idx); ?>: false,
                                    onCepInput(e) {
                                        let raw = e.target.value.replace(/\D/g, '').substring(0, 8);
                                        let f = '';
                                        for (let i = 0; i < raw.length; i++) { f += raw[i]; if (i === 4 && raw.length > 5) f += '-'; }
                                        e.target.value = f;
                                        this.cep<?php echo e($idx); ?> = raw;
                                        this.$wire.set('enderecos.<?php echo e($idx); ?>.cep', f);
                                        this.cepErro<?php echo e($idx); ?> = '';
                                        if (raw.length === 8) this.buscarCep(raw);
                                    },
                                    buscarCep(cep) {
                                        this.buscando<?php echo e($idx); ?> = true; this.cepErro<?php echo e($idx); ?> = '';
                                        let wire = this.$wire; let el = this.$el; let idx = <?php echo e($idx); ?>;
                                        fetch('https://viacep.com.br/ws/' + cep + '/json/')
                                            .then(r => r.json()).then(data => {
                                                if (data.erro) { this.cepErro<?php echo e($idx); ?> = 'CEP não encontrado.'; return; }
                                                wire.set('enderecos.' + idx + '.logradouro', data.logradouro || '');
                                                wire.set('enderecos.' + idx + '.bairro', data.bairro || '');
                                                if (data.uf) {
                                                    let sel = el.querySelector('.estado-select-' + idx);
                                                    if (sel) { for (let i = 0; i < sel.options.length; i++) {
                                                        if (sel.options[i].text.startsWith(data.uf)) {
                                                            sel.value = sel.options[i].value;
                                                            sel.dispatchEvent(new Event('change', { bubbles: true }));
                                                            break;
                                                        }
                                                    }}
                                                }
                                            }).catch(() => { this.cepErro<?php echo e($idx); ?> = 'Erro ao buscar CEP.'; })
                                            .finally(() => { this.buscando<?php echo e($idx); ?> = false; });
                                    }
                                }">
                                    <div class="grid-4" style="gap:6px;margin-bottom:6px;">
                                        <div class="field"><label>Título</label><input wire:model="enderecos.<?php echo e($idx); ?>.titulo" placeholder="Principal"></div>
                                        <div class="field" style="grid-column:span 3;"><label>Logradouro</label><input wire:model="enderecos.<?php echo e($idx); ?>.logradouro" placeholder="Rua..."></div>
                                    </div>
                                    <div class="grid-4" style="gap:6px;margin-bottom:6px;">
                                        <div class="field"><label>Número</label><input wire:model="enderecos.<?php echo e($idx); ?>.numero" placeholder="S/N"></div>
                                        <div class="field"><label>Bairro</label><input wire:model="enderecos.<?php echo e($idx); ?>.bairro" placeholder="Centro"></div>
                                        <div class="field"><label>CEP</label>
                                            <input x-init="if (cep<?php echo e($idx); ?>) { let v = cep<?php echo e($idx); ?>; $el.value = v.substring(0,5) + '-' + v.substring(5); }" placeholder="00000-000" maxlength="9" @input.debounce.200ms="onCepInput($event)">
                                            <div x-show="cepErro<?php echo e($idx); ?>" style="color:var(--danger);font-size:11px;margin-top:2px;" x-text="cepErro<?php echo e($idx); ?>"></div>
                                            <div x-show="buscando<?php echo e($idx); ?>" style="font-size:11px;color:var(--muted);margin-top:2px;"><i class="fas fa-spinner fa-spin"></i> Buscando...</div>
                                        </div>
                                        <div class="field"><label>Complemento</label><input wire:model="enderecos.<?php echo e($idx); ?>.complemento" placeholder="Galpão..."></div>
                                    </div>
                                    <div class="grid-4" style="gap:6px;">
                                        <div class="field"><label>Estado</label>
                                            <select wire:model.live="enderecos.<?php echo e($idx); ?>.estado_id" class="estado-select-<?php echo e($idx); ?>">
                                                <option value="">Selecione...</option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <option value="<?php echo e($e['id']); ?>"><?php echo e($e['uf']); ?> - <?php echo e($e['nome']); ?></option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="field" style="grid-column:span 2;"><label>Cidade</label>
                                            <select wire:model="enderecos.<?php echo e($idx); ?>.cidade_id">
                                                <option value="">Selecione...</option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($end['estado_id']): ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Cidade::where('estado_id', (int)$end['estado_id'])->orderBy('nome')->get(['id','nome']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                        <option value="<?php echo e($cidade->id); ?>"><?php echo e($cidade->nome); ?></option>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="field" style="display:flex;align-items:end;padding-bottom:4px;">
                                            <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;color:var(--text);margin-bottom:0;"><input wire:model="enderecos.<?php echo e($idx); ?>.principal" type="checkbox" style="width:16px;height:16px;"> Principal</label>
                                        </div>
                                    </div>
                                    <button type="button" wire:click="removerEndereco(<?php echo e($idx); ?>)" class="apres-remove">&times;</button>
                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <div class="sub-card" style="text-align:center;padding:24px;color:var(--muted);font-size:13px;">
                                    <i class="fas fa-map-marker-alt" style="font-size:24px;display:block;margin-bottom:8px;opacity:0.3;"></i>
                                    Nenhum endereço cadastrado.
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        
                        <div x-show="activeTab === 'compras'">
                            <div class="section-border">Histórico de Compras</div>
                            <?php $compras = $this->comprasCliente; ?>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                                <div class="sub-card">
                                    <div class="section-title" style="margin-bottom:8px;">PDV (Balcão)</div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $compras['pdv']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;">
                                            <span style="font-weight:600;">#<?php echo e($v['id']); ?></span>
                                            <span style="color:var(--muted);"><?php echo e(\Carbon\Carbon::parse($v['created_at'])->format('d/m/Y')); ?></span>
                                            <span style="font-weight:700;">R$ <?php echo e(number_format($v['total'], 2, ',', '.')); ?></span>
                                            <span class="badge-sm <?php echo e($v['status'] === 'concluida' ? 'badge-ativo' : 'badge-inativo'); ?>"><?php echo e($v['status']); ?></span>
                                        </div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        <div style="text-align:center;padding:20px;color:var(--muted);font-size:12px;">Nenhuma venda.</div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <div class="sub-card">
                                    <div class="section-title" style="margin-bottom:8px;">Delivery</div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $compras['pedidos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;">
                                            <span style="font-weight:600;"><?php echo e($p['codigo']); ?></span>
                                            <span style="color:var(--muted);"><?php echo e(\Carbon\Carbon::parse($p['created_at'])->format('d/m/Y')); ?></span>
                                            <span style="font-weight:700;">R$ <?php echo e(number_format($p['total'], 2, ',', '.')); ?></span>
                                            <span class="badge-sm <?php echo e($p['status'] === 'entregue' ? 'badge-ativo' : 'badge-warning'); ?>"><?php echo e($p['status']); ?></span>
                                        </div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        <div style="text-align:center;padding:20px;color:var(--muted);font-size:12px;">Nenhum pedido.</div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        
                        <div x-show="activeTab === 'financeiro'">
                            <div class="section-border">Financeiro</div>
                            <div class="sub-card">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->financeiroCliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;">
                                        <span style="font-weight:600;"><?php echo e($l['descricao']); ?></span>
                                        <span style="color:var(--muted);"><?php echo e(\Carbon\Carbon::parse($l['data_vencimento'])->format('d/m/Y')); ?></span>
                                        <span style="font-weight:700;color:<?php echo e($l['tipo'] === 'receita' ? 'var(--success)' : 'var(--danger)'); ?>;">R$ <?php echo e(number_format($l['valor'], 2, ',', '.')); ?></span>
                                        <span class="badge-sm <?php echo e($l['status'] === 'pago' ? 'badge-ativo' : ($l['status'] === 'atrasado' ? 'badge-inativo' : 'badge-warning')); ?>"><?php echo e($l['status']); ?></span>
                                    </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    <div style="text-align:center;padding:20px;color:var(--muted);font-size:12px;">Nenhum lançamento financeiro.</div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        
                        <div x-show="activeTab === 'grupos'">
                            <div class="section-border">Grupos do Cliente</div>
                            <div class="sub-card">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->gruposDisponiveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <label style="display:flex;align-items:center;gap:10px;font-size:14px;font-weight:600;cursor:pointer;color:var(--text);height:40px;padding:0 4px;border-bottom:1px solid var(--border);">
                                        <input wire:model="gruposSelecionados" type="checkbox" value="<?php echo e($g['id']); ?>" style="width:18px;height:18px;">
                                        <?php echo e($g['nome']); ?>

                                    </label>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    <div style="text-align:center;padding:20px;color:var(--muted);font-size:12px;">Nenhum grupo cadastrado.</div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        
                        <div x-show="activeTab === 'fidelidade'">
                            <div class="section-border">Programa de Fidelidade</div>
                            <?php $pts = $this->pontosCliente; ?>
                            <div style="display:grid;grid-template-columns:1fr 2fr;gap:16px;">
                                <div class="sub-card" style="text-align:center;">
                                    <div style="font-size:40px;font-weight:900;color:var(--primary-600);"><?php echo e($pts['total']); ?></div>
                                    <div style="font-size:12px;color:var(--muted);font-weight:600;margin-top:4px;">Pontos Ativos</div>
                                </div>
                                <div class="sub-card" style="max-height:300px;overflow-y:auto;">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $pts['historico']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;">
                                            <span><?php echo e($m['descricao'] ?? $m['tipo']); ?></span>
                                            <span style="color:var(--muted);"><?php echo e(\Carbon\Carbon::parse($m['created_at'])->format('d/m/Y')); ?></span>
                                            <span style="font-weight:700;color:<?php echo e($m['tipo'] === 'credito' ? 'var(--success)' : 'var(--danger)'); ?>;"><?php echo e($m['tipo'] === 'credito' ? '+' : '-'); ?><?php echo e($m['pontos']); ?></span>
                                        </div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        <div style="text-align:center;padding:20px;color:var(--muted);font-size:12px;">Nenhuma movimentação.</div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        
                        <div x-show="activeTab === 'config'">
                            <div class="section-border">Configurações</div>
                            <div class="sub-card">
                                <div style="display:flex;flex-direction:column;gap:12px;">
                                    <label style="display:flex;align-items:center;gap:10px;font-size:14px;font-weight:600;cursor:pointer;color:var(--text);height:36px;"><input wire:model="ativo" type="checkbox" checked style="width:18px;height:18px;"> Cliente ativo</label>
                                    <label style="display:flex;align-items:center;gap:10px;font-size:14px;font-weight:600;cursor:pointer;color:var(--text);height:36px;"><input wire:model="aceita_marketing" type="checkbox" style="width:18px;height:18px;"> Aceita marketing</label>
                                </div>
                            </div>
                        </div>

                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['exclusao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err" style="margin-bottom:8px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <div class="form-actions">
                            <button type="submit" class="btn-primary btn-lg"><span wire:loading.remove><i class="fas fa-save"></i> <?php echo e($this->modo === 'create' ? 'Salvar' : 'Atualizar'); ?></span><span wire:loading>Salvando...</span></button>
                            <button type="button" wire:click="voltarLista" class="btn-secondary btn-lg">Cancelar</button>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($viewState === 'detail'): ?>
                                <button type="button" wire:click="excluir(<?php echo e($this->editandoId); ?>)" wire:confirm="Excluir cliente?" class="btn-danger btn-lg" style="margin-left:auto;">Excluir</button>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($viewState === 'detail'): ?>
            <div style="display:flex;flex-direction:column;gap:16px;">
                <div class="sidebar-card">
                    <div class="sidebar-card-header"><i class="fas fa-receipt"></i> Resumo</div>
                    <div class="sidebar-card-body">
                        <div class="resumo-list">
                            <div class="resumo-row"><span class="resumo-label">Nome</span><span class="resumo-value" style="font-weight:800;"><?php echo e($this->nome ?: '—'); ?></span></div>
                            <div class="resumo-row"><span class="resumo-label">Email</span><span class="resumo-value"><?php echo e($this->email ?: '—'); ?></span></div>
                            <div class="resumo-row"><span class="resumo-label">CPF</span><span class="resumo-value-mono"><?php echo e($this->cpf ?: '—'); ?></span></div>
                            <div class="resumo-row"><span class="resumo-label">WhatsApp</span><span class="resumo-value"><?php echo e($this->whatsapp ?: '—'); ?></span></div>
                            <div class="resumo-row"><span class="resumo-label">Endereços</span><span class="resumo-value"><?php echo e(count($this->enderecos)); ?></span></div>
                            <div class="resumo-row"><span class="resumo-label">Grupos</span><span class="resumo-value"><?php echo e(count($this->gruposSelecionados)); ?></span></div>
                            <div class="resumo-row"><span class="resumo-label">Status</span><span class="resumo-badge <?php echo e($this->ativo ? 'resumo-badge-ativo' : 'resumo-badge-inativo'); ?>"><?php echo e($this->ativo ? 'Ativo' : 'Inativo'); ?></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/cliente-manager.blade.php ENDPATH**/ ?>