<div>
    <div x-data="{ show: <?php if ((object) ('toastShow') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'->value()); ?>')<?php echo e('toastShow'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'); ?>')<?php endif; ?>, msg: <?php if ((object) ('toastMsg') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'->value()); ?>')<?php echo e('toastMsg'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'); ?>')<?php endif; ?> }"
         x-init="$watch('show', val => { if(val) setTimeout(() => show = false, 4000) })"
         x-show="show" class="toast-fixed" x-cloak>
        <span class="toast-icon"><i class="fas fa-check"></i></span><span x-text="msg"></span>
    </div>
    <div class="main-content-pad">
        <div class="header-row">
            <div>
                <div class="admin-badge"><i class="fas fa-crown"></i> ADMIN</div>
                <h1 class="page-title">Central de Pedidos Online</h1>
                <div class="breadcrumb">
                    <span>Inicio</span><i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <span>Operacional</span><i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <span class="breadcrumb-active">Pedidos Online</span>
                </div>
            </div>
            <div class="status-online"><span class="status-dot"></span> Conectado</div>
        </div>

        <?php $t = $this->totais; ?>
        <div class="metrics-grid" style="grid-template-columns:repeat(6,1fr);">
            <div class="metric-card" style="padding:10px;"><div><span class="metric-label" style="font-size:9px;">Pedidos Hoje</span><span class="metric-value" style="font-size:18px;"><?php echo e($t['hoje']); ?></span></div></div>
            <div class="metric-card" style="padding:10px;border-left:3px solid var(--primary-500);"><div><span class="metric-label" style="font-size:9px;">Novos</span><span class="metric-value" style="font-size:18px;color:var(--primary-600);"><?php echo e($t['novos']); ?></span></div></div>
            <div class="metric-card" style="padding:10px;border-left:3px solid var(--warning);"><div><span class="metric-label" style="font-size:9px;">Em Separacao</span><span class="metric-value" style="font-size:18px;color:var(--warning);"><?php echo e($t['separacao']); ?></span></div></div>
            <div class="metric-card" style="padding:10px;border-left:3px solid var(--success);"><div><span class="metric-label" style="font-size:9px;">Prontos</span><span class="metric-value" style="font-size:18px;color:var(--success);"><?php echo e($t['prontos']); ?></span></div></div>
            <div class="metric-card" style="padding:10px;border-left:3px solid var(--danger);"><div><span class="metric-label" style="font-size:9px;">Atrasados</span><span class="metric-value" style="font-size:18px;color:var(--danger);"><?php echo e($t['atrasados']); ?></span></div></div>
            <div class="metric-card" style="padding:10px;"><div><span class="metric-label" style="font-size:9px;">Faturamento</span><span class="metric-value" style="font-size:18px;">R$ <?php echo e(number_format($t['faturamento'], 0, ',', '.')); ?></span></div></div>
        </div>

        <div class="sub-card" style="margin-bottom:16px;display:flex;gap:8px;align-items:end;flex-wrap:wrap;">
            <div class="field" style="flex:1;min-width:180px;margin:0;"><label>Buscar</label><input wire:model.live.debounce.300ms="busca" placeholder="Codigo ou cliente..." style="height:34px;font-size:12px;"></div>
            <div class="field" style="width:130px;margin:0;"><label>Status</label><select wire:model.live="filtroStatus" style="height:34px;font-size:11px;"><option value="">Todos</option><option value="recebido">Recebido</option><option value="confirmado">Confirmado</option><option value="em_separacao">Em Separacao</option><option value="pronto_retirada">Pronto Retirada</option><option value="pronto_entrega">Pronto Entrega</option><option value="entregue">Entregue</option><option value="cancelado">Cancelado</option></select></div>
            <div class="field" style="width:110px;margin:0;"><label>Periodo</label><select wire:model.live="periodo" style="height:34px;font-size:11px;"><option value="hoje">Hoje</option><option value="semana">Semana</option><option value="personalizado">Personalizado</option></select></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($periodo === 'personalizado'): ?>
                <div class="field" style="width:100px;margin:0;"><input wire:model="dataInicio" type="date" style="height:34px;font-size:11px;"></div>
                <div class="field" style="width:100px;margin:0;"><input wire:model="dataFim" type="date" style="height:34px;font-size:11px;"></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="field" style="width:110px;margin:0;"><label>Entrega</label><select wire:model.live="filtroEntrega" style="height:34px;font-size:11px;"><option value="">Todas</option><option value="retirada">Retirada</option><option value="entrega">Entrega</option></select></div>
        </div>

        <?php $lista = $this->listagem(); ?>
        <div style="display:grid;grid-template-columns:1fr <?php echo e($this->detalheId ? '440px' : '0'); ?>;gap:16px;align-items:start;transition:0.3s;">
            
            <div class="data-table-wrap">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($lista) > 0): ?>
                    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;padding:12px;">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php $st = $this->statusDoPedido($p); ?>
                            <div wire:click="verDetalhe(<?php echo e($p->id); ?>)" style="cursor:pointer;background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:14px;transition:all 0.15s;<?php echo e($st['atrasado'] ? 'border-left:4px solid var(--danger);' : ''); ?><?php echo e($this->detalheId === $p->id ? 'box-shadow:0 0 0 2px var(--primary-500);' : ''); ?>" onmouseover="this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" onmouseout="this.style.boxShadow='none'">
                                <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:8px;">
                                    <div>
                                        <span style="font-weight:800;font-size:14px;color:var(--text);">#<?php echo e($p->id); ?></span>
                                        <span style="font-size:11px;color:var(--muted);font-family:monospace;margin-left:4px;"><?php echo e($p->codigo); ?></span>
                                    </div>
                                    <?php
                                        $badgeClass = match($p->status) {
                                            'recebido' => 'badge-ativo',
                                            'em_separacao' => 'badge-warning',
                                            'pronto_retirada','pronto_entrega','entregue' => 'badge-ativo',
                                            'cancelado' => 'badge-inativo',
                                            default => 'badge-warning',
                                        };
                                    ?>
                                    <span class="badge-sm <?php echo e($badgeClass); ?>" style="font-size:8px;"><?php echo e($p->status); ?></span>
                                </div>
                                <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:6px;"><?php echo e($p->cliente?->nome ?? '—'); ?></div>
                                <div style="display:flex;gap:12px;font-size:11px;color:var(--muted);margin-bottom:6px;">
                                    <span><i class="fas fa-box"></i> <?php echo e($p->itens->count()); ?> itens</span>
                                    <span><i class="fas fa-dollar-sign"></i> R$ <?php echo e(number_format($p->total, 2, ',', '.')); ?></span>
                                    <span><i class="fas <?php echo e($p->tipo_entrega === 'entrega' ? 'fa-truck' : 'fa-store'); ?>"></i> <?php echo e($p->tipo_entrega); ?></span>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($st['atrasado']): ?>
                                    <div style="font-size:11px;font-weight:700;color:var(--danger);display:flex;align-items:center;gap:4px;">
                                        <i class="fas fa-exclamation-circle"></i> ATRASADO <?php echo e($st['minutos_atraso']); ?>min
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($p->separador): ?>
                                    <div style="font-size:10px;color:var(--muted);margin-top:4px;">
                                        <i class="fas fa-user-cog"></i> Sep: <?php echo e($p->separador->name); ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($p->entregador): ?> | <i class="fas fa-motorcycle"></i> Ent: <?php echo e($p->entregador->name); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <div style="font-size:9px;color:var(--muted);margin-top:4px;"><?php echo e($p->created_at->format('d/m/Y H:i')); ?></div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php else: ?>
                    <div style="text-align:center;padding:40px;color:var(--muted);">
                        <i class="fas fa-inbox" style="font-size:40px;display:block;margin-bottom:10px;opacity:0.3;"></i>
                        <p style="font-size:16px;font-weight:600;color:var(--text);margin:0 0 4px;">Nenhum pedido encontrado</p>
                        <p style="font-size:13px;margin:0;">Os pedidos feitos no site aparecerao aqui.</p>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lista->hasPages()): ?>
                    <div style="padding:12px 16px;border-top:1px solid var(--border);"><?php echo e($lista->links('livewire.pagination-custom')); ?></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->detalheId): ?>
                <?php $d = $this->detalhe; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($d): ?>
                    <div style="position:sticky;top:16px;">
                        <div style="border:1px solid var(--border);border-radius:16px;overflow:hidden;background:var(--surface);max-height:90vh;overflow-y:auto;">
                            <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
                                <h3 style="margin:0;font-size:16px;font-weight:800;color:var(--text);">Pedido #<?php echo e($d['id']); ?></h3>
                                <button wire:click="fecharDetalhe" style="background:none;border:0;color:var(--muted);cursor:pointer;font-size:20px;padding:0;">&times;</button>
                            </div>

                            <div style="padding:14px 20px;border-bottom:1px solid var(--border);">
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px;">
                                    <div><strong style="color:var(--muted);display:block;font-size:10px;">Cliente</strong><?php echo e($d['cliente']['nome'] ?? '—'); ?></div>
                                    <div><strong style="color:var(--muted);display:block;font-size:10px;">Total</strong><span style="font-weight:800;color:var(--success);">R$ <?php echo e(number_format($d['total'], 2, ',', '.')); ?></span></div>
                                    <div><strong style="color:var(--muted);display:block;font-size:10px;">Data</strong><?php echo e(\Carbon\Carbon::parse($d['created_at'])->format('d/m/Y H:i')); ?></div>
                                    <div><strong style="color:var(--muted);display:block;font-size:10px;">Codigo</strong><span style="font-family:monospace;"><?php echo e($d['codigo']); ?></span></div>
                                    <div><strong style="color:var(--muted);display:block;font-size:10px;">Tipo</strong><?php echo e($d['tipo_entrega']); ?></div>
                                    <div><strong style="color:var(--muted);display:block;font-size:10px;">Status</strong>
                                        <?php $badgeClass = match($d['status']) { 'recebido'=>'badge-ativo','em_separacao'=>'badge-warning','pronto_retirada'=>'badge-ativo','entregue'=>'badge-ativo','cancelado'=>'badge-inativo', default => 'badge-warning' }; ?>
                                        <span class="badge-sm <?php echo e($badgeClass); ?>"><?php echo e($d['status']); ?></span>
                                    </div>
                                </div>
                            </div>

                            
                            <div style="padding:14px 20px;border-bottom:1px solid var(--border);">
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                                    <div>
                                        <label style="font-size:10px;color:var(--muted);display:block;margin-bottom:2px;">Separador</label>
                                        <select wire:model="separadorId" style="width:100%;height:30px;font-size:11px;padding:0 4px;border:1px solid var(--border);border-radius:5px;">
                                            <option value="">—</option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <option value="<?php echo e($op['id']); ?>"><?php echo e($op['name']); ?></option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label style="font-size:10px;color:var(--muted);display:block;margin-bottom:2px;">Entregador</label>
                                        <select wire:model="entregadorId" style="width:100%;height:30px;font-size:11px;padding:0 4px;border:1px solid var(--border);border-radius:5px;">
                                            <option value="">—</option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <option value="<?php echo e($op['id']); ?>"><?php echo e($op['name']); ?></option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <button wire:click="salvarOperadores" class="btn-sm btn-primary" style="margin-top:6px;height:28px;font-size:10px;width:100%;"><i class="fas fa-save"></i> Salvar Operadores</button>
                            </div>

                            
                            <div style="padding:14px 20px;border-bottom:1px solid var(--border);">
                                <h4 style="margin:0 0 8px;font-size:13px;font-weight:700;color:var(--text);">Itens (<?php echo e(count($d['itens'])); ?>)</h4>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $d['itens']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <?php $v = $item['variacao'] ?? []; ?>
                                    <div style="padding:8px 0;border-bottom:1px solid color-mix(in srgb,var(--border)50%,transparent);">
                                        <div style="display:flex;justify-content:space-between;align-items:start;gap:6px;">
                                            <div style="flex:1;">
                                                <div style="font-size:12px;font-weight:600;color:var(--text);text-transform:uppercase;"><?php echo e($v['nome_completo'] ?? '#' . $item['produto_variacao_id']); ?></div>
                                                <div style="font-size:10px;color:var(--muted);"><?php echo e(number_format($item['quantidade_solicitada'], 3, ',', '.')); ?> x R$ <?php echo e(number_format($item['preco_unitario'], 2, ',', '.')); ?></div>
                                            </div>
                                            <div style="text-align:right;flex-shrink:0;">
                                                <span style="font-size:11px;font-weight:700;color:var(--text);">R$ <?php echo e(number_format($item['total_item'], 2, ',', '.')); ?></span>
                                                <div style="margin-top:2px;">
                                                    <?php $ic = match($item['status_item']) { 'pendente'=>'badge-warning', 'separado'=>'badge-ativo', 'faltou'=>'badge-inativo', 'substituido'=>'badge-ativo', 'cancelado'=>'badge-inativo', default=>'badge-warning' }; ?>
                                                    <span class="badge-sm <?php echo e($ic); ?>" style="font-size:8px;"><?php echo e($item['status_item']); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div style="display:flex;gap:4px;margin-top:4px;flex-wrap:wrap;">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['status_item'] === 'pendente'): ?>
                                                <button wire:click="alterarStatusItem(<?php echo e($item['id']); ?>, 'separado')" class="btn-sm" style="padding:2px 6px;font-size:8px;height:22px;background:color-mix(in srgb,var(--success)10%,transparent);color:var(--success);border:0;border-radius:4px;cursor:pointer;"><i class="fas fa-check"></i> Separar</button>
                                                <button wire:click="alterarStatusItem(<?php echo e($item['id']); ?>, 'faltou')" class="btn-sm" style="padding:2px 6px;font-size:8px;height:22px;background:color-mix(in srgb,var(--danger)10%,transparent);color:var(--danger);border:0;border-radius:4px;cursor:pointer;"><i class="fas fa-times"></i> Faltou</button>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['status_item'] === 'faltou' || $item['status_item'] === 'pendente'): ?>
                                                <button wire:click="sugerirSubstituto(<?php echo e($item['id']); ?>)" class="btn-sm" style="padding:2px 6px;font-size:8px;height:22px;background:color-mix(in srgb,var(--primary-500)10%,transparent);color:var(--primary-600);border:0;border-radius:4px;cursor:pointer;"><i class="fas fa-exchange-alt"></i> Substituto</button>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['substituto_produto_variacao_id'] && $item['substituto']): ?>
                                                <div style="font-size:10px;color:var(--muted);margin-top:2px;width:100%;">
                                                    Subst: <strong><?php echo e($item['substituto']['nome_completo'] ?? '#' . $item['substituto_produto_variacao_id']); ?></strong>
                                                </div>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                    </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>

                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->itemSubstituir): ?>
                                <div style="padding:14px 20px;border-bottom:1px solid var(--border);">
                                    <h4 style="margin:0 0 8px;font-size:13px;font-weight:700;color:var(--text);">Buscar Substituto</h4>
                                    <input wire:model.live.debounce.300ms="buscaSubstituto" wire:input="buscarSubstituto" placeholder="Nome do produto..." style="width:100%;height:34px;padding:0 8px;border:1px solid var(--border);border-radius:6px;font-size:12px;margin-bottom:6px;">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($this->resultadosSubstituto) > 0): ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->resultadosSubstituto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <button wire:click="$set('substitutoId', <?php echo e($pr['id']); ?>)" style="display:block;width:100%;text-align:left;padding:6px 8px;border:0;border-bottom:1px solid var(--border);background:<?php echo e($this->substitutoId === $pr['id'] ? 'color-mix(in srgb,var(--primary-500)10%,transparent)' : 'transparent'); ?>;cursor:pointer;font-size:11px;color:var(--text);">
                                                <strong><?php echo e($pr['nome_completo']); ?></strong>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($pr['marca']['nome'])): ?> <span style="color:var(--muted);">— <?php echo e($pr['marca']['nome']); ?></span> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </button>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <div style="display:flex;gap:4px;margin-top:6px;">
                                        <button wire:click="confirmarSubstituicao" class="btn-sm btn-primary" style="height:28px;font-size:10px;">Confirmar</button>
                                        <button wire:click="cancelarSubstituicao" class="btn-sm btn-secondary" style="height:28px;font-size:10px;">Cancelar</button>
                                    </div>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            
                            <div style="padding:14px 20px;">
                                <h4 style="margin:0 0 8px;font-size:13px;font-weight:700;color:var(--text);">Acoes</h4>
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;">
                                    <?php $acoes = ['recebido'=>'Recebido','confirmado'=>'Confirmar','em_separacao'=>'Separar','pronto_retirada'=>'Pronto Retirada','pronto_entrega'=>'Pronto Entrega','entregue'=>'Entregue','cancelado'=>'Cancelar']; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $acoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($key !== $d['status']): ?>
                                            <button wire:click="alterarStatus(<?php echo e($d['id']); ?>, '<?php echo e($key); ?>')" class="btn-sm <?php echo e($key === 'cancelado' ? 'btn-remove' : 'btn-secondary'); ?>" style="height:30px;font-size:10px;padding:0 6px;"><?php echo e($label); ?></button>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/pedido-online-manager.blade.php ENDPATH**/ ?>