<div style="font-family:'Inter',system-ui,sans-serif;min-height:100vh;background:color-mix(in srgb,var(--text)4%,var(--background));color:var(--text);">

    <?php if (isset($component)) { $__componentOriginal657dba54d2631c9c0f1aaca7d14d51d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal657dba54d2631c9c0f1aaca7d14d51d7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.vitrine-header','data' => ['carrinhoCount' => 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('vitrine-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['carrinhoCount' => 0]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal657dba54d2631c9c0f1aaca7d14d51d7)): ?>
<?php $attributes = $__attributesOriginal657dba54d2631c9c0f1aaca7d14d51d7; ?>
<?php unset($__attributesOriginal657dba54d2631c9c0f1aaca7d14d51d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal657dba54d2631c9c0f1aaca7d14d51d7)): ?>
<?php $component = $__componentOriginal657dba54d2631c9c0f1aaca7d14d51d7; ?>
<?php unset($__componentOriginal657dba54d2631c9c0f1aaca7d14d51d7); ?>
<?php endif; ?>

    <div style="max-width:800px;margin:0 auto;padding:1rem;">
        
        <div style="display:flex;gap:4px;overflow-x:auto;margin-top:-1.25rem;margin-bottom:1.25rem;scrollbar-width:none;">
            <?php $abas = ['dados'=>'Meus Dados','pedidos'=>'Pedidos','enderecos'=>'Enderecos','seguranca'=>'Seguranca']; $icons = ['dados'=>'fa-user','pedidos'=>'fa-box','enderecos'=>'fa-map-marker-alt','seguranca'=>'fa-lock']; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $abas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <button wire:click="$set('aba','<?php echo e($key); ?>')" style="flex-shrink:0;padding:0.6rem 1.2rem;border-radius:999px;font-size:0.82rem;font-weight:600;border:none;cursor:pointer;transition:0.2s;<?php echo e($aba === $key ? 'background:var(--primary-500);color:#fff;box-shadow:0 4px 12px color-mix(in srgb,var(--primary-500)30%,transparent);' : 'background:var(--surface);color:var(--muted);border:1px solid var(--border);'); ?>">
                    <i class="fas <?php echo e($icons[$key]); ?>" style="margin-right:4px;"></i> <?php echo e($label); ?>

                </button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($aba === 'dados' && $c): ?>
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:1rem;padding:1.25rem;">
                <h2 style="font-size:1.1rem;font-weight:700;margin:0 0 1rem;color:var(--text);">Meus Dados</h2>
                <form wire:submit="salvarDados">
                    <div style="margin-bottom:0.75rem;">
                        <label style="display:block;font-size:0.72rem;font-weight:600;color:var(--muted);margin-bottom:0.25rem;">Nome completo</label>
                        <input wire:model="edit_nome" style="width:100%;padding:0.7rem 0.9rem;border-radius:0.6rem;border:1px solid var(--border);font-size:0.9rem;color:var(--text);background:var(--surface);outline:none;box-sizing:border-box;">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['edit_nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p style="margin:0.2rem 0 0;font-size:0.72rem;color:var(--danger);"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div style="display:flex;flex-wrap:wrap;gap:0.75rem;margin-bottom:0.75rem;">
                        <div style="flex:1;min-width:150px;">
                            <label style="display:block;font-size:0.72rem;font-weight:600;color:var(--muted);margin-bottom:0.25rem;">E-mail</label>
                            <input wire:model="edit_email" type="email" style="width:100%;padding:0.7rem 0.9rem;border-radius:0.6rem;border:1px solid var(--border);font-size:0.9rem;color:var(--text);background:var(--surface);outline:none;box-sizing:border-box;">
                        </div>
                        <div style="flex:1;min-width:150px;">
                            <label style="display:block;font-size:0.72rem;font-weight:600;color:var(--muted);margin-bottom:0.25rem;">WhatsApp</label>
                            <input wire:model="edit_whatsapp" type="tel" style="width:100%;padding:0.7rem 0.9rem;border-radius:0.6rem;border:1px solid var(--border);font-size:0.9rem;color:var(--text);background:var(--surface);outline:none;box-sizing:border-box;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['edit_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p style="margin:0.2rem 0 0;font-size:0.72rem;color:var(--danger);"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div style="display:flex;flex-wrap:wrap;gap:0.75rem;margin-bottom:1rem;">
                        <div style="flex:1;min-width:150px;">
                            <label style="display:block;font-size:0.72rem;font-weight:600;color:var(--muted);margin-bottom:0.25rem;">CPF</label>
                            <input wire:model="edit_cpf" style="width:100%;padding:0.7rem 0.9rem;border-radius:0.6rem;border:1px solid var(--border);font-size:0.9rem;color:var(--text);background:var(--surface);outline:none;box-sizing:border-box;">
                        </div>
                        <div style="flex:1;min-width:150px;">
                            <label style="display:block;font-size:0.72rem;font-weight:600;color:var(--muted);margin-bottom:0.25rem;">Data Nasc.</label>
                            <input wire:model="edit_data_nascimento" type="date" style="width:100%;padding:0.7rem 0.9rem;border-radius:0.6rem;border:1px solid var(--border);font-size:0.9rem;color:var(--text);background:var(--surface);outline:none;box-sizing:border-box;">
                        </div>
                    </div>
                    <button type="submit" style="width:100%;padding:0.7rem;background:var(--primary-500);color:#fff;border:none;border-radius:0.6rem;font-size:0.88rem;font-weight:600;cursor:pointer;">Salvar alteracoes</button>
                </form>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($aba === 'pedidos'): ?>
            <?php $pedidos = $this->pedidosRecentes; ?>
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:1rem;padding:1.25rem;">
                <h2 style="font-size:1.1rem;font-weight:700;margin:0 0 1rem;color:var(--text);">Meus Pedidos</h2>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($pedidos) > 0): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php $pTotal = number_format($p['total'],2,',','.'); ?>
                        <div style="padding:0.75rem 0;border-bottom:1px solid var(--border);">
                            <div style="display:flex;justify-content:space-between;align-items:start;">
                                <div>
                                    <strong style="font-size:0.9rem;color:var(--text);">Pedido #<?php echo e($p['id']); ?></strong>
                                    <span style="font-size:0.75rem;color:var(--muted);margin-left:6px;"><?php echo e(\Carbon\Carbon::parse($p['created_at'])->format('d/m/Y')); ?></span>
                                    <div style="font-size:0.8rem;color:var(--muted);margin-top:2px;"><?php echo e(count($p['itens'])); ?> itens · R$ <?php echo e($pTotal); ?></div>
                                </div>
                                <div style="text-align:right;flex-shrink:0;">
                                    <span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:0.65rem;font-weight:600;background:color-mix(in srgb,var(--success)10%,transparent);color:var(--success);"><?php echo e($p['status']); ?></span>
                                    <button wire:click="verPedido(<?php echo e($p['id']); ?>)" style="display:block;margin-top:4px;padding:2px 8px;border:1px solid var(--border);border-radius:6px;background:transparent;font-size:0.72rem;cursor:pointer;color:var(--primary-500);">Detalhes</button>
                                </div>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php else: ?>
                    <div style="text-align:center;padding:1.5rem;color:var(--muted);font-size:0.85rem;">Nenhum pedido encontrado.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->pedidoDetalhe): ?>
                <?php $p = $this->pedidoDetalhe; ?>
                <div style="background:var(--surface);border:1px solid var(--border);border-radius:1rem;padding:1.25rem;margin-top:0.75rem;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.5rem;">
                        <h3 style="margin:0;font-size:1rem;font-weight:700;color:var(--text);">Pedido #<?php echo e($p['id']); ?></h3>
                        <button wire:click="fecharPedido" style="padding:4px 10px;border:1px solid var(--border);border-radius:6px;background:transparent;font-size:0.75rem;cursor:pointer;color:var(--muted);">Fechar</button>
                    </div>
                    <div style="font-size:0.78rem;color:var(--muted);margin-bottom:0.5rem;"><?php echo e(\Carbon\Carbon::parse($p['created_at'])->format('d/m/Y H:i')); ?> · <strong style="color:var(--primary-500);"><?php echo e($p['status']); ?></strong></div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $p['itens']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php $v = $item['variacao'] ?? []; $itemNome = $v['nome_completo'] ?? 'Produto'; ?>
                        <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--border);font-size:0.82rem;">
                            <span style="color:var(--text);"><?php echo e($itemNome); ?> <span style="color:var(--muted);font-size:0.7rem;">x<?php echo e(number_format($item['quantidade_solicitada'],1,',','.')); ?></span></span>
                            <span style="font-weight:600;color:var(--text);">R$ <?php echo e(number_format($item['total_item'],2,',','.')); ?></span>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div style="text-align:right;margin-top:0.5rem;font-size:1rem;font-weight:700;color:var(--text);">Total: R$ <?php echo e(number_format($p['total'],2,',','.')); ?></div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($aba === 'enderecos' && $c): ?>
            <?php $enderecos = $this->enderecos; ?>
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:1rem;padding:1.25rem;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
                    <h2 style="font-size:1.1rem;font-weight:700;margin:0;color:var(--text);">Enderecos</h2>
                    <button wire:click="novoEndereco" style="padding:6px 14px;background:var(--primary-500);color:#fff;border:none;border-radius:0.6rem;font-size:0.78rem;font-weight:600;cursor:pointer;">+ Novo</button>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($enderecos) > 0): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php $ePri = $e['principal']; $eTit = $e['titulo'] ?? ''; ?>
                        <div style="padding:0.75rem 0;border-bottom:1px solid var(--border);">
                            <div style="display:flex;justify-content:space-between;align-items:start;gap:8px;">
                                <div style="flex:1;min-width:0;">
                                    <strong style="font-size:0.88rem;color:var(--text);"><?php echo e($e['logradouro']); ?><?php echo e($e['numero'] ? ', '.$e['numero'] : ''); ?></strong><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ePri): ?> <span style="background:var(--primary-500);color:#fff;font-size:0.55rem;padding:1px 6px;border-radius:4px;font-weight:700;vertical-align:middle;">PRINCIPAL</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <div style="font-size:0.78rem;color:var(--muted);margin-top:2px;"><?php echo e($e['bairro'] ?? ''); ?><?php echo e($eTit ? ' · '.$eTit : ''); ?><?php echo e($e['cep'] ? ' · CEP '.$e['cep'] : ''); ?></div>
                                </div>
                                <div style="display:flex;gap:4px;flex-shrink:0;">
                                    <button wire:click="editarEndereco(<?php echo e($e['id']); ?>)" style="padding:3px 8px;border:1px solid var(--border);border-radius:5px;background:transparent;font-size:0.7rem;cursor:pointer;color:var(--text);">Editar</button>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$ePri): ?><button wire:click="definirEnderecoPrincipal(<?php echo e($e['id']); ?>)" style="padding:3px 8px;border:1px solid var(--border);border-radius:5px;background:transparent;font-size:0.7rem;cursor:pointer;color:var(--muted);">⭐</button><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$ePri): ?><button wire:click="excluirEndereco(<?php echo e($e['id']); ?>)" style="padding:3px 8px;border:1px solid var(--border);border-radius:5px;background:transparent;font-size:0.7rem;cursor:pointer;color:var(--danger);"><i class="fas fa-trash"></i></button><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php else: ?>
                    <div style="text-align:center;padding:1.5rem;color:var(--muted);font-size:0.85rem;">Nenhum endereco cadastrado.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($aba === 'seguranca' && $c): ?>
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:1rem;padding:1.25rem;">
                <h2 style="font-size:1.1rem;font-weight:700;margin:0 0 1rem;color:var(--text);">Seguranca</h2>
                <form wire:submit="alterarSenha">
                    <div style="margin-bottom:0.75rem;">
                        <label style="display:block;font-size:0.72rem;font-weight:600;color:var(--muted);margin-bottom:0.25rem;">Senha atual</label>
                        <input wire:model="senha_atual" type="password" style="width:100%;padding:0.7rem 0.9rem;border-radius:0.6rem;border:1px solid var(--border);font-size:0.9rem;color:var(--text);background:var(--surface);outline:none;box-sizing:border-box;">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['senha_atual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p style="margin:0.2rem 0 0;font-size:0.72rem;color:var(--danger);"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div style="display:flex;flex-wrap:wrap;gap:0.75rem;margin-bottom:0.75rem;">
                        <div style="flex:1;min-width:150px;">
                            <label style="display:block;font-size:0.72rem;font-weight:600;color:var(--muted);margin-bottom:0.25rem;">Nova senha</label>
                            <input wire:model="senha_nova" type="password" style="width:100%;padding:0.7rem 0.9rem;border-radius:0.6rem;border:1px solid var(--border);font-size:0.9rem;color:var(--text);background:var(--surface);outline:none;box-sizing:border-box;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['senha_nova'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p style="margin:0.2rem 0 0;font-size:0.72rem;color:var(--danger);"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div style="flex:1;min-width:150px;">
                            <label style="display:block;font-size:0.72rem;font-weight:600;color:var(--muted);margin-bottom:0.25rem;">Confirmar</label>
                            <input wire:model="senha_confirmacao" type="password" style="width:100%;padding:0.7rem 0.9rem;border-radius:0.6rem;border:1px solid var(--border);font-size:0.9rem;color:var(--text);background:var(--surface);outline:none;box-sizing:border-box;">
                        </div>
                    </div>
                    <button type="submit" style="width:100%;padding:0.7rem;background:var(--primary-500);color:#fff;border:none;border-radius:0.6rem;font-size:0.88rem;font-weight:600;cursor:pointer;">Alterar senha</button>
                </form>
            </div>
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:1rem;padding:1.25rem;margin-top:0.75rem;">
                <button wire:click="logout" style="padding:0.6rem 1.25rem;background:color-mix(in srgb,var(--danger)10%,transparent);color:var(--danger);border:1px solid color-mix(in srgb,var(--danger)20%,transparent);border-radius:0.6rem;font-weight:600;font-size:0.82rem;cursor:pointer;">Sair da conta</button>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/cliente-conta-manager.blade.php ENDPATH**/ ?>