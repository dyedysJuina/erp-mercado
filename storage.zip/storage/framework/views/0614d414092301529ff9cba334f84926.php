<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Etiquetas</title>
    <style>
        @page { margin: 8mm; size: A4; }
        body { font-family: 'Courier New', monospace; margin: 0; padding: 0; }
        .page { display: grid; grid-template-columns: repeat(3, 1fr); gap: 4mm; }
        .label {
            border: 1px dashed #ccc;
            padding: 4mm;
            text-align: center;
            page-break-inside: avoid;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 50mm;
        }
        .label .nome { font-size: 10px; font-weight: 700; text-transform: uppercase; margin-bottom: 2mm; line-height: 1.2; }
        .label .preco { font-size: 22px; font-weight: 900; color: #c00; margin: 2mm 0; }
        .label .preco-label { font-size: 8px; color: #666; }
        .label .codigo { font-size: 18px; font-weight: 300; letter-spacing: 2px; margin: 2mm 0; font-family: 'Courier New', monospace; }
        .label .sku { font-size: 8px; color: #999; margin-top: 1mm; }
        .label .marca { font-size: 8px; color: #666; }
        .label .validade { font-size: 7px; color: #999; margin-top: 1mm; }
        .no-print { text-align: center; margin: 10mm 0; }
        .no-print button { padding: 10px 30px; font-size: 16px; cursor: pointer; }
        @media print {
            .no-print { display: none; }
            .label { border: none; }
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()">Imprimir Etiquetas</button>
        <button onclick="window.close()">Fechar</button>
    </div>
    <div class="page">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 0; $i < $qtd; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php
                    $preco = isset($precos[$p->id]) ? (float)$precos[$p->id]->{$campo} : 0;
                    $codigo = $p->codigosBarras?->firstWhere('principal', true)?->codigo ?? $p->sku ?? '';
                    $marca = $p->marca?->nome ?? '';
                ?>
                <div class="label">
                    <div class="marca"><?php echo e($marca); ?></div>
                    <div class="nome"><?php echo e($p->nome_completo); ?></div>
                    <div class="preco-label">Preco <?php echo e($campo === 'preco_atacado' ? 'Atacado' : 'Venda'); ?></div>
                    <div class="preco">R$ <?php echo e(number_format($preco, 2, ',', '.')); ?></div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($codigo): ?>
                        <div class="codigo"><?php echo e($codigo); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="sku">SKU: <?php echo e($p->sku ?? '-'); ?></div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/fiscal/etiquetas-print.blade.php ENDPATH**/ ?>