<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;background:#0f172a;">
    <section style="max-width:480px;width:100%;padding:24px;background:#fff;border-radius:20px;text-align:center;">
        <span style="color:var(--success);font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:1px;">Pagamento</span>
        <h2 style="font-size:36px;font-weight:900;color:#0f172a;margin:8px 0 4px;">R$ <?php echo e(number_format($this->total, 2, ',', '.')); ?></h2>
        <p style="color:#64748b;font-size:13px;margin-bottom:16px;">Adicione formas de pagamento</p>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($this->pagamentos) > 0): ?>
            <div style="margin-bottom:12px;text-align:left;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->pagamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-radius:8px;margin-bottom:4px;background:<?php echo e($pg['tipo'] === 'dinheiro' ? '#f0fdf4' : ($pg['tipo'] === 'pix' ? '#f0f9ff' : '#faf5ff')); ?>;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <span style="font-size:18px;">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pg['tipo'] === 'dinheiro'): ?> <i class="fas fa-money-bill-wave" style="color:var(--success);"></i>
                                <?php elseif($pg['tipo'] === 'pix'): ?> <i class="fa-brands fa-pix" style="color:#00b4d8;"></i>
                                <?php elseif(str_contains($pg['tipo'] ?? '', 'debito')): ?> <i class="fas fa-credit-card" style="color:#3b82f6;"></i>
                                <?php elseif(str_contains($pg['tipo'] ?? '', 'credito')): ?> <i class="fas fa-credit-card" style="color:#8b5cf6;"></i>
                                <?php else: ?> <i class="fas fa-credit-card"></i> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </span>
                            <span style="font-weight:600;font-size:13px;color:#0f172a;"><?php echo e($pg['nome']); ?></span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <span style="font-weight:700;font-size:14px;color:#0f172a;">R$ <?php echo e(number_format($pg['valor'], 2, ',', '.')); ?></span>
                            <button wire:click="removerPagamento(<?php echo e($idx); ?>)" style="background:none;border:0;color:var(--danger);cursor:pointer;font-size:14px;">&times;</button>
                        </div>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div style="display:flex;justify-content:space-between;padding:8px 4px;font-size:13px;font-weight:700;color:#0f172a;border-top:2px solid #0f172a;margin-top:6px;">
                    <span>Total pago</span>
                    <span>R$ <?php echo e(number_format($this->totalPago, 2, ',', '.')); ?></span>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->restantePagar > 0.01): ?>
                    <div style="text-align:right;font-size:12px;color:var(--warning);font-weight:600;margin-top:2px;">Restante: R$ <?php echo e(number_format($this->restantePagar, 2, ',', '.')); ?></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:14px;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->formasPagamento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <button type="button" wire:click="adicionarPagamento(<?php echo e($fp['id']); ?>)" style="padding:12px 6px;border-radius:10px;border:1px solid var(--border);background:#fff;cursor:pointer;text-align:center;">
                    <div style="font-size:22px;margin-bottom:4px;">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($fp['tipo'] === 'dinheiro'): ?> <i class="fas fa-money-bill-wave" style="color:var(--success);"></i>
                        <?php elseif($fp['tipo'] === 'pix'): ?> <i class="fa-brands fa-pix" style="color:#00b4d8;"></i>
                        <?php elseif(str_contains($fp['tipo'] ?? '', 'debito')): ?> <i class="fas fa-credit-card" style="color:#3b82f6;"></i>
                        <?php elseif(str_contains($fp['tipo'] ?? '', 'credito')): ?> <i class="fas fa-credit-card" style="color:#8b5cf6;"></i>
                        <?php else: ?> <i class="fas fa-credit-card"></i> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <span style="font-size:11px;font-weight:600;color:#0f172a;"><?php echo e($fp['nome']); ?></span>
                </button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->restantePagar > 0.01): ?>
            <div style="margin-bottom:14px;">
                <label style="font-size:12px;font-weight:600;color:#475569;display:block;margin-bottom:4px;text-align:left;">Valor em dinheiro</label>
                <div style="display:flex;align-items:center;border:1px solid var(--border);border-radius:10px;overflow:hidden;">
                    <span style="padding:0 14px;color:#64748b;font-weight:700;font-size:14px;">R$</span>
                    <input wire:model.live.debounce.200ms="valorRecebido" type="text" placeholder="<?php echo e(number_format($this->restantePagar, 2, ',', '.')); ?>" style="border:0;flex:1;height:44px;outline:none;padding:0 14px;font-size:15px;font-weight:700;color:#0f172a;">
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php $trocoCalc = $this->trocoCalculado; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trocoCalc > 0): ?>
            <div style="display:flex;justify-content:space-between;padding:12px;border-radius:10px;background:#f0fdf4;color:var(--success);font-weight:700;font-size:16px;margin-bottom:14px;border:2px solid #bbf7d0;">
                <span><i class="fas fa-arrow-left"></i> Troco</span>
                <span>R$ <?php echo e(number_format($trocoCalc, 2, ',', '.')); ?></span>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['forma_pagamento_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="color:var(--danger);font-size:12px;margin-bottom:8px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['caixa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="padding:10px;border-radius:8px;background:#fef2f2;color:var(--danger);font-size:12px;margin-bottom:12px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div style="display:flex;gap:8px;">
            <button wire:click="voltarVenda" style="flex:1;padding:14px;border:1px solid var(--border);border-radius:10px;background:#fff;cursor:pointer;font-weight:700;color:#475569;">Voltar</button>
            <button wire:click="finalizar" wire:loading.attr="disabled" style="flex:1;padding:14px;border:0;border-radius:10px;background:var(--success);color:#fff;cursor:pointer;font-weight:800;" <?php if($this->restantePagar > 0.01 || count($this->pagamentos) === 0): echo 'disabled'; endif; ?>>
                <span wire:loading.remove>Finalizar</span>
                <span wire:loading>...</span>
            </button>
        </div>
    </section>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/pdv/pagamento.blade.php ENDPATH**/ ?>