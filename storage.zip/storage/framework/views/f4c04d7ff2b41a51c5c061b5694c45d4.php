<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;background:#0f172a;">
    <section style="max-width:420px;width:100%;padding:28px;background:#fff;border-radius:20px;text-align:center;">
        <div style="width:54px;height:54px;margin:0 auto 16px;border-radius:16px;background:#f0fdf4;color:var(--success);display:grid;place-items:center;font-size:30px;font-weight:900;">
            <i class="fas fa-check-circle"></i>
        </div>
        <h2 style="margin:0;font-size:22px;color:#0f172a;">Venda concluída</h2>
        <p style="color:#64748b;font-size:13px;">Venda #<?php echo e($this->vendaId); ?></p>
        <strong style="display:block;margin:16px 0;font-size:32px;color:#0f172a;">R$ <?php echo e(number_format($this->totalFinalizado, 2, ',', '.')); ?></strong>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((float) str_replace(['.', ','], ['', '.'], $this->troco) > 0): ?>
            <div style="display:flex;justify-content:space-between;padding:12px;border-radius:10px;background:#f0fdf4;color:var(--success);font-weight:700;margin-bottom:16px;">
                <span>Troco</span><span>R$ <?php echo e($this->troco); ?></span>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div style="margin-top:16px;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->nfceStatus === 'rascunho'): ?>
                <span style="display:block;font-size:12px;color:#64748b;margin-bottom:8px;">NFC-e gerada como rascunho</span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->nfceDocumentoId): ?>
                    <a href="<?php echo e(route('fiscal.danfe', $this->nfceDocumentoId)); ?>" target="_blank" style="display:block;width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:8px;background:#fff;color:#0f172a;font-weight:700;text-decoration:none;margin-bottom:6px;">Visualizar DANFE</a>
                    <a href="<?php echo e(route('fiscal.xml', $this->nfceDocumentoId)); ?>" target="_blank" style="display:block;width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:8px;background:#fff;color:#0f172a;font-weight:700;text-decoration:none;">Download XML</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php elseif($this->nfceStatus === 'autorizada'): ?>
                <span style="display:block;font-size:12px;color:var(--success);margin-bottom:8px;">NFC-e autorizada ✓</span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->nfceDocumentoId): ?>
                    <a href="<?php echo e(route('fiscal.danfe', $this->nfceDocumentoId)); ?>" target="_blank" style="display:block;width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:8px;background:#fff;color:#0f172a;font-weight:700;text-decoration:none;">Visualizar DANFE</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php elseif($this->nfceStatus === 'erro'): ?>
                <span style="display:block;font-size:12px;color:var(--danger);margin-bottom:8px;">Erro ao emitir NFC-e</span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['nfce'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-size:11px;color:var(--danger);"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php else: ?>
                <button wire:click="emitirNfce" wire:loading.attr="disabled" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:8px;background:#fff;color:#0f172a;font-weight:700;cursor:pointer;">
                    <span wire:loading.remove>Emitir NFC-e</span>
                    <span wire:loading>Emitindo...</span>
                </button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <button wire:click="abrirEstorno" style="width:100%;margin-top:8px;padding:10px;border:1px solid #e2e8f0;border-radius:8px;background:#fff;color:var(--danger);font-weight:700;cursor:pointer;font-size:13px;">
            <i class="fas fa-undo-alt"></i> Estornar Venda
        </button>

        <button wire:click="novaVenda" style="width:100%;margin-top:8px;padding:12px;border:0;border-radius:10px;background:var(--success);color:#fff;font-weight:800;cursor:pointer;">
            Nova venda
        </button>
    </section>

    
    <div x-show="$wire.estornoModalOpen" style="position:fixed;inset:0;z-index:999;background:rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center;padding:20px;" @click.self="$wire.set('estornoModalOpen', false)" x-cloak>
        <div style="background:#fff;border-radius:20px;padding:24px;max-width:400px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.2);">
            <h3 style="margin:0 0 12px;font-size:16px;color:#0f172a;display:flex;align-items:center;gap:8px;">
                <span style="width:32px;height:32px;border-radius:50%;background:#fef2f2;display:grid;place-items:center;color:var(--danger);"><i class="fas fa-undo-alt"></i></span>
                Estornar Venda #<?php echo e($this->vendaId); ?>

            </h3>
            <p style="font-size:13px;color:#64748b;margin-bottom:14px;">Isso irá cancelar a venda, estornar o estoque e cancelar o lançamento financeiro. Informe o motivo:</p>
            <div style="margin-bottom:14px;">
                <select wire:model="estornoMotivo" style="width:100%;padding:10px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;color:#0f172a;">
                    <option value="">Selecione...</option>
                    <option value="Cliente desistiu">Cliente desistiu</option>
                    <option value="Produto danificado">Produto danificado</option>
                    <option value="Erro na finalização">Erro na finalização</option>
                    <option value="Troca/devolução">Troca / Devolução</option>
                </select>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['estornoMotivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="font-size:11px;color:var(--danger);margin-top:2px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <div style="display:flex;gap:8px;">
                <button type="button" wire:click="$set('estornoModalOpen', false)" style="flex:1;padding:12px;border:1px solid #e2e8f0;border-radius:10px;background:#fff;cursor:pointer;font-weight:700;color:#475569;">Cancelar</button>
                <button type="button" wire:click="confirmarEstorno" style="flex:1;padding:12px;border:0;border-radius:10px;background:var(--danger);color:#fff;cursor:pointer;font-weight:800;">
                    <span wire:loading.remove>Confirmar Estorno</span>
                    <span wire:loading>Estornando...</span>
                </button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/pdv/finalizada.blade.php ENDPATH**/ ?>