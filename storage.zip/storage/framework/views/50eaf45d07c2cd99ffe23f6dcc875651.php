<div>
    <div x-data="{ show: <?php if ((object) ('toastShow') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'->value()); ?>')<?php echo e('toastShow'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastShow'); ?>')<?php endif; ?>, msg: <?php if ((object) ('toastMsg') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'->value()); ?>')<?php echo e('toastMsg'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('toastMsg'); ?>')<?php endif; ?> }"
         x-init="$watch('show', val => { if(val) setTimeout(() => show = false, 4000) })"
         x-show="show" class="toast-fixed" x-cloak>
        <span class="toast-icon"><i class="fas fa-check"></i></span><span x-text="msg"></span>
    </div>
    <div class="main-content-pad">
        <div class="header-row">
            <div>
                <h1 class="page-title" style="font-size:22px;">Dashboard Executivo</h1>
                <div class="breadcrumb">
                    <span>Inicio</span><i class="fas fa-chevron-right breadcrumb-arrow"></i>
                    <span class="breadcrumb-active">Dashboard</span>
                </div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;">
                <div class="field" style="margin:0;width:180px;"><select wire:model.live="lojaFiltro" style="height:36px;font-size:12px;"><option value="">Todas as Lojas</option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->lojas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><option value="<?php echo e($l['id']); ?>"><?php echo e($l['nome']); ?></option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></select></div>
            </div>
        </div>

        <?php $d = $this->dados; ?>

        <div class="metrics-grid" style="grid-template-columns:repeat(4,1fr);">
            <div class="metric-card" style="padding:18px;">
                <div><span class="metric-label" style="font-size:10px;">Faturamento Hoje</span>
                    <span class="metric-value" style="font-size:24px;color:var(--success);">R$ <?php echo e(number_format($d['fat_hoje'], 2, ',', '.')); ?></span>
                    <span class="metric-sub"><?php echo e($d['vendas_hoje']); ?> venda(s) - Ticket medio R$ <?php echo e(number_format($d['ticket_medio'], 2, ',', '.')); ?></span>
                </div>
                <div class="metric-icon green" style="width:40px;height:40px;font-size:16px;"><i class="fas fa-cash-register"></i></div>
            </div>
            <div class="metric-card" style="padding:18px;">
                <div><span class="metric-label" style="font-size:10px;">Faturamento do Mes</span>
                    <span class="metric-value" style="font-size:24px;">R$ <?php echo e(number_format($d['fat_mes'], 2, ',', '.')); ?></span>
                    <span class="metric-sub"><?php echo e(now()->format('F/Y')); ?></span>
                </div>
                <div class="metric-icon blue" style="width:40px;height:40px;font-size:16px;"><i class="fas fa-calendar"></i></div>
            </div>
            <div class="metric-card" style="padding:18px;">
                <div><span class="metric-label" style="font-size:10px;">Produtos em Estoque Critico</span>
                    <span class="metric-value" style="font-size:24px;color:var(--warning);"><?php echo e(count($d['estoque_critico'])); ?></span>
                    <span class="metric-sub">Precisam de reposicao</span>
                </div>
                <div class="metric-icon amber" style="width:40px;height:40px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
            </div>
            <div class="metric-card" style="padding:18px;">
                <div><span class="metric-label" style="font-size:10px;">Contas Atrasadas (Receber)</span>
                    <span class="metric-value" style="font-size:24px;color:var(--danger);"><?php echo e(count($d['inadimplentes'])); ?></span>
                    <span class="metric-sub">Valor total: R$ <?php echo e(number_format(collect($d['inadimplentes'])->sum('valor'), 2, ',', '.')); ?></span>
                </div>
                <div class="metric-icon" style="width:40px;height:40px;border-radius:10px;font-size:16px;background:color-mix(in srgb,var(--danger)12%,transparent);color:var(--danger);"><i class="fas fa-hand-holding"></i></div>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start;">
            <div class="card" style="padding:16px;">
                <h4 style="margin:0 0 12px;font-size:13px;font-weight:700;color:var(--text);">Vendas - Ultimos 7 Dias</h4>
                <div style="display:flex;align-items:end;gap:6px;height:120px;padding:10px 0;">
                    <?php $maxValor = max(1, collect($d['grafico_7dias'])->max('total')); ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $d['grafico_7dias']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php $altura = max(4, ($g['total'] / $maxValor) * 100); ?>
                        <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;">
                            <span style="font-size:9px;font-weight:700;color:var(--muted);">R$ <?php echo e(number_format($g['total'], 0, ',', '.')); ?></span>
                            <div style="width:100%;border-radius:4px 4px 0 0;background:var(--primary-600);height:<?php echo e($altura); ?>px;min-height:4px;transition:height 0.3s;"></div>
                            <span style="font-size:8px;color:var(--muted);"><?php echo e($g['dia']); ?></span>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>

            <div class="card" style="padding:16px;">
                <h4 style="margin:0 0 12px;font-size:13px;font-weight:700;color:var(--text);">Top 10 Produtos (Mes)</h4>
                <div style="max-height:220px;overflow-y:auto;">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $d['top_produtos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;">
                            <span style="width:22px;height:22px;border-radius:50%;background:color-mix(in srgb,var(--primary-500)10%,transparent);color:var(--primary-600);display:flex;align-items:center;justify-content:center;font-weight:900;font-size:10px;flex-shrink:0;"><?php echo e($i + 1); ?></span>
                            <span style="flex:1;font-weight:600;text-transform:uppercase;font-size:11px;"><?php echo e($p->nome_completo); ?></span>
                            <span style="font-weight:700;color:var(--text);"><?php echo e(number_format($p->qtd, 0, ',', '.')); ?> un</span>
                            <span style="color:var(--success);font-weight:700;font-size:11px;">R$ <?php echo e(number_format($p->total, 2, ',', '.')); ?></span>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <div style="text-align:center;padding:20px;color:var(--muted);font-size:12px;">Nenhum produto vendido no mes.</div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:16px;">
            <div class="card" style="padding:16px;">
                <h4 style="margin:0 0 12px;font-size:13px;font-weight:700;color:var(--text);"><i class="fas fa-exclamation-triangle" style="color:var(--warning);"></i> Estoque Critico</h4>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $d['estoque_critico']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;">
                        <span style="font-weight:600;text-transform:uppercase;font-size:11px;flex:1;"><?php echo e($e->nome_completo); ?></span>
                        <span style="color:var(--danger);font-weight:700;"><?php echo e(number_format($e->quantidade_atual, 3, ',', '.')); ?></span>
                        <span style="color:var(--muted);font-size:10px;">/ min <?php echo e(number_format($e->estoque_minimo, 3, ',', '.')); ?></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div style="text-align:center;padding:20px;color:var(--muted);font-size:12px;">Nenhum produto com estoque critico.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="card" style="padding:16px;">
                <h4 style="margin:0 0 12px;font-size:13px;font-weight:700;color:var(--text);"><i class="fas fa-hand-holding" style="color:var(--danger);"></i> Inadimplencia - Contas Atrasadas</h4>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $d['inadimplentes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;">
                        <div style="flex:1;">
                            <span style="font-weight:600;display:block;font-size:11px;"><?php echo e($i->descricao); ?></span>
                            <span style="font-size:10px;color:var(--muted);">Venc: <?php echo e(\Carbon\Carbon::parse($i->data_vencimento)->format('d/m/Y')); ?></span>
                        </div>
                        <span style="color:var(--danger);font-weight:700;">R$ <?php echo e(number_format($i->valor, 2, ',', '.')); ?></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div style="text-align:center;padding:20px;color:var(--muted);font-size:12px;">Nenhuma conta atrasada.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/livewire/dashboard-executivo-manager.blade.php ENDPATH**/ ?>