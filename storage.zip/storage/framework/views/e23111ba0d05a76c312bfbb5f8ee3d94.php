<?php
$overridesCss = app(\App\Services\ThemeService::class)->getAllOverridesCss();
$activeTheme = app(\App\Models\Theme::class)->where('is_active', true)->first();
$defaultSlug = $activeTheme?->slug ?? 'verde';
?>
<!doctype html>
<html lang="pt-BR" data-theme="<?php echo e($defaultSlug); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($overridesCss): ?>
        <style id="database-theme-tokens"><?php echo $overridesCss; ?></style>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</head>
<body style="margin:0;min-height:100vh;display:flex;font-family:'Inter',system-ui,sans-serif;">
    <?php echo e($slot); ?>

</body>
</html>
<?php /**PATH C:\wamp64\www\erp_mercado\resources\views/layouts/guest.blade.php ENDPATH**/ ?>